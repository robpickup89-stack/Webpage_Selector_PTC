﻿// Viewer options
var viewmode = 0;
var refresh = 1; // Default to enabled
var buttons = 0;

// History options
var historyArray = [];
var historylevel = 0;
var timeoutTeller = 0;
var timeoutInterval = null;

let lastRequestTime = 0;
const DEBOUNCE_MS = 1000;

// Cache for optional file checks
const optionalFileCache = new Map();

startTimeout();

function startTimeout() {
  if (timeoutInterval) clearInterval(timeoutInterval);
  timeoutInterval = setInterval(() => {
    timeoutTeller++;
    if (timeoutTeller >= 20) {
      if (top.frames['content_frame']) {
        top.frames['content_frame'].location.href = "/hvi?file=editor/parseData&uic=3145&page=/frames/home/homePage";
        timeoutTeller = 0;
      } else {
        //console.warn('startTimeout: content_frame not available');
      }
    }
  }, 60000);
}

function stopTimeout() {
  if (timeoutInterval) {
    clearInterval(timeoutInterval);
    timeoutInterval = null;
  }
}

function userActivity() {
  timeoutTeller = 0;
}

function doHref(pg, level) {
  const pag = `/hvi?file=/${pg}&uic=3145`;
  historyArray[level] = pag;
  historylevel = level;
  userActivity();
  if (top.frames['content_frame'] && top.frames['content_frame'].document) {
    top.frames['content_frame'].document.location.href = pag;
  } else {
    //console.error('doHref: content_frame not available, falling back to top');
    top.location.href = pag;
  }
}

function doDataHref(pg, level) {
  const now = Date.now();
  if (now - lastRequestTime < DEBOUNCE_MS) return;
  lastRequestTime = now;
  let pag;
  if (pg.startsWith('/frames/live/')) {
    pag = `/hvi?file=${pg.substring(1)}`;
  } else {
    pag = `/hvi?file=editor/parseData&uic=3145&page=${pg}`;
  }
  historyArray[level] = pag;
  historylevel = level;
  userActivity();
  top.refresh = 1; // Default to refresh, overridden by init if :EDIT;1
  if (top.frames['content_frame'] && top.frames['content_frame'].document) {
    top.frames['content_frame'].document.location.href = pag;
  } else {
    console.error('doDataHref: content_frame not available, falling back to top');
    top.location.href = pag;
  }
}

function doUFHref(pg, uf, value) {
  let pag;
  if (value) {
    pag = `/hvi?file=editor/parseData&uic=3145&page=/${pg}&uf=${uf}&val=${value}`;
  } else {
    pag = `/hvi?file=editor/parseData&uic=3145&page=/${pg}&uf=${uf}`;
  }
  userActivity();
  if (top.frames['content_frame'] && top.frames['content_frame'].document) {
    top.frames['content_frame'].document.location.href = pag;
  } else {
    //console.error('doUFHref: content_frame not available, falling back to top');
    top.location.href = pag;
  }
}

function dispHtml(pg) {
  if (top.frames['content_frame'] && top.frames['content_frame'].document) {
    top.frames['content_frame'].document.location.href = pg;
  } else {
    //console.error('dispHtml: content_frame not available, falling back to top');
    top.location.href = pg;
  }
}

function openFaultHelpWindow() {
  window.open('/frames/log/faultHelp', '_blank', 'width=800,height=600');
}

async function check_url(url, callback_function) {
  let callback;
  let frameExists = false;

  // Check cache for optional files
  if (optionalFileCache.has(url)) {
    //console.log(`check_url: Using cached result for ${url}: ${optionalFileCache.get(url)}`);
    if (typeof callback_function === 'function') {
      callback_function(optionalFileCache.get(url));
    } else if (typeof callback_function === 'string' && typeof window[callback_function] === 'function') {
      window[callback_function](optionalFileCache.get(url));
    }
    return;
  }

  if (typeof callback_function === 'string') {
    try {
      const path = callback_function.split('.');
      //console.log('check_url: Resolving callback path:', path);
      callback = path.reduce((obj, key) => {
        if (obj && key in obj) {
          return obj[key];
        }
        throw new Error(`Property ${key} not found in ${callback_function}`);
      }, window);
      frameExists = path[0] === 'top' && path[1] in top && typeof top[path[1]][path[2]] === 'function';
    } catch (e) {
      //console.error('check_url: Failed to resolve callback:', callback_function, e);
      return;
    }
  } else if (typeof callback_function === 'function') {
    callback = callback_function;
    frameExists = true;
  }

  if (typeof callback !== 'function') {
    //console.error('check_url: Invalid callback function:', callback_function);
    return;
  }

  if (!frameExists) {
    //console.warn(`check_url: Frame or function ${callback_function} not available`);
    callback(0);
    return;
  }

  //console.log('check_url: Checking URL:', url);
  try {
    const response = await fetch(url, {
      method: 'GET',
      cache: 'no-store'
    });
    http_status = 0;
    const result = response.ok ? 1 : 0;
    if (!response.ok && ['customPage', 'layout.txt', 'report01.html'].includes(url)) {
      //console.log(`check_url: Optional file ${url} not found (Status ${response.status})`);
      optionalFileCache.set(url, 0);
    } else if (response.ok) {
      optionalFileCache.set(url, 1);
    }
    callback(result);
  } catch (error) {
    http_status = 0;
    //console.warn(`check_url: Fetch error for ${url}:`, error.message);
    if (['customPage', 'layout.txt', 'report01.html'].includes(url)) {
      optionalFileCache.set(url, 0);
    }
    callback(0);
  }
}