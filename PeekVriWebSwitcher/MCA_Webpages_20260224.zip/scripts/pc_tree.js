﻿window.onbeforeunload = exit;
// Create a top level variable that indicates that this is a pctree view
// (html) and not a tft view.
top.isPcTree = true;

function tree_init()
{

	rollup();
	SetScrollPosition();
	//ClearCookies();
}

function exit()
{
	SaveTreeStatus();
}

function SetScrollPosition()
{
	var scrollPostion = GetCookie( "line" );
	window.scrollBy(0, scrollPostion );
}

function SetCookie( name, value ) {
  var argv = SetCookie.arguments;
  var argc = SetCookie.arguments.length;
  var expires = (argc > 2) ? argv[2] : null;
  var path = (argc > 3) ? argv[3] : null;
  var domain = (argc > 4) ? argv[4] : null;
  var secure = (argc > 5) ? argv[5] : false;
  document.cookie = name + "=" + escape (value) +
    ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) +
    ((path == null) ? "" : ("; path=" + path)) +
    ((domain == null) ? "" : ("; domain=" + domain)) +
    ((secure == true) ? "; secure" : "");
}

// Get Cookie function
function GetCookie(name) {
   var arg = name+"=";
   var alen = arg.length;
   var clen = document.cookie.length;
   var i = 0;
   while (i < clen) {
      var j = i + alen;
      if (document.cookie.substring(i, j) == arg) return getCookieVal(j);
      i = document.cookie.indexOf(" ", i) + 1;
      if (i == 0) break;
   }
   return null;
}

function getCookieVal(offset) {
   var endstr = document.cookie.indexOf (";", offset);
   if (endstr == -1) endstr = document.cookie.length;
   return unescape (document.cookie.substring(offset, endstr));
}


function showall()
{
  var objMenu =  document.getElementById('mainnav');
  var objNested = objMenu.getElementsByTagName('ul');

  for (var i=0; i<objNested.length; i++)
  {
    var objMenuitem = objNested[i].parentNode;
    rollout( objMenuitem.firstChild, null );	
  } 
}

function SaveTreeStatus()
{
  var scrollTop = 0;
  var expDays = 30; 
  var exp = new Date(); 
  exp.setTime(exp.getTime() + (expDays*30*24*60*60*1000)); 
   	
  var objMenu = document.getElementById('mainnav');
  var objNested = objMenu.getElementsByTagName('ul');
  for (var i=0; i<objNested.length; i++)
  {
    var objNode = objNested[i].parentNode;	
    //alert( "saving: " + i + " = " + objNode.firstChild.nextSibling.style.display );
    SetCookie( i, objNode.firstChild.nextSibling.style.display, exp );
  }
    
  if (document.documentElement && document.documentElement.scrollTop)
    scrollTop = document.documentElement.scrollTop
  else if (document.body)
  	scrollTop = document.body.scrollTop
  else
	  scrollTop = window.pageYOffset;
    
  SetCookie( "line", scrollTop, exp ); 
}

function ClearCookies()
{
  var objMenu = document.getElementById('mainnav');
  var objNested = objMenu.getElementsByTagName('ul');
  
  // Hide each of the nested unordered list
  for (var i=0; i<objNested.length; i++)
  {		
    document.cookie = i += "=; expires= 0" ;
  } 
}

function Highlight(objHighlightedLink) {
  if (!top.content_frame || !top.content_frame.window || !top.content_frame.window.location) {
    console.warn('content_frame not loaded in Highlight');
    return false;
  }
  var strLocation = top.content_frame.window.location;
  var objSpan = objHighlightedLink.parentNode.getElementsByTagName('span')[0];
  if (!objSpan) {
    console.warn('No span found in Highlight');
    return false;
  }
  var objGlobalSpan = document.getElementsByTagName('span');
  for (var j = 0; j < objGlobalSpan.length; j++) {
    objGlobalSpan[j].className = (objGlobalSpan[j] === objSpan) ? 'highlight' : '';
  }
  return true;
}

function rollout(objMenuitem, objEvent) {
  if (!objMenuitem || !objMenuitem.nextSibling) {
    console.warn('No nextSibling in rollout');
    return false;
  }
  var iKeyCode;
  if (objEvent && objEvent.type === 'keypress') {
    iKeyCode = objEvent.keyCode || objEvent.which;
    if (iKeyCode !== 13 && iKeyCode !== 32) return true;
  }
  var imgObj = objMenuitem.getElementsByTagName('img');
  if (!imgObj[0]) {
    console.warn('No image in rollout');
    return false;
  }
  if (objMenuitem.nextSibling.style.display === 'block') {
    objMenuitem.nextSibling.style.display = 'none';
    imgObj[0].setAttribute('src', '/images/folder_closed.png');
  } else {
    objMenuitem.nextSibling.style.display = 'block';
    imgObj[0].setAttribute('src', '/images/folder_open.png');
  }
  return false;
}

function rollup() {
  if (!document.getElementById || !document.createElement) {
    console.warn('DOM not supported in rollup');
    return;
  }
  var objMenu = document.getElementById('mainnav');
  if (!objMenu) {
    console.warn('mainnav not found in rollup');
    return;
  }
  var strLocation = top.content_frame?.window?.location || '';
  var objNested = objMenu.getElementsByTagName('ul');
  var rExp = /_/g;

  // Attach onmouseup to all <a> tags in #mainnav (top-level and nested)
  var objAllLinks = objMenu.getElementsByTagName('a');
  for (var j = 0; j < objAllLinks.length; j++) {
    // Only attach to links with a <span> (leaf items, not folder links)
    if (objAllLinks[j].getElementsByTagName('span').length > 0) {
      objAllLinks[j].onmouseup = function(event) { return Highlight(this); };
    }
  }

  for (var i = 0; i < objNested.length; i++) {
    var bRollup = true;
    var objNode = objNested[i].parentNode;
    if (!objNode.firstChild) {
      console.warn(`No firstChild for node ${i} in rollup`);
      continue;
    }
    var strContent = objNode.firstChild.data || '';
    var CurNestedStyle = GetCookie(i);
    objNested[i].style.display = (CurNestedStyle === 'none') ? 'none' : 'block';
    bRollup = (CurNestedStyle === 'none');

    var imageObj = document.createElement('img');
    imageObj.setAttribute('src', bRollup ? '/images/folder_closed.png' : '/images/folder_open.png');
    var objAnchor = document.createElement('a');
    objAnchor.href = '#';
    objAnchor.onmousedown = function(event) { return rollout(this, event); };
    objAnchor.onkeypress = function(event) { return rollout(this, event); };
    objAnchor.appendChild(imageObj);
    objAnchor.appendChild(document.createTextNode(strContent.replace(rExp, ' ')));
    objNode.replaceChild(objAnchor, objNode.firstChild);
  }

  var objSpan = document.getElementsByTagName('span');
  for (var i = 0; i < objSpan.length; i++) {
    var strText = objSpan[i].lastChild?.nodeValue;
    if (strText) {
      var newText = strText.replace(rExp, ' ');
      if (newText !== strText) {
        var newObj = document.createElement('span');
        newObj.appendChild(document.createTextNode(newText));
        objSpan[i].replaceChild(newObj, objSpan[i].firstChild || objSpan[i].lastChild);
      }
    }
  }
}