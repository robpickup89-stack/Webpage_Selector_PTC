﻿// javascript.js
// To ensure this script isn’t cached, append a cache-busting query: /scripts/javascript.js?_=<timestamp>

// Global variables
var datapage = "/frames/home/homePage";
var pagesize = 25;
var refresh = 0;
var buttons = 0;

var pos1 = 0;
var pos2 = pagesize - 1;
var maxpage = 1;
var lastpagesize = 0;
var editpos = 0;

var helpwindow_id;

// Load data options
var title;
var subtitle;
var edit = 0;
var min_items = 0;
var max_items = 0;

var http_buffer = "";
var http_status = 0;
let abortController = null;
let lastValidHttpBuffer = ""; // Store last valid data

// Button texts
var BTN_BACK_TEXT = "Back";
var BTN_REFRESH_TEXT1 = "Refresh";
var BTN_REFRESH_TEXT2 = "Freeze";
var BTN_EDIT_PROXY = "Edit";
var BTN_EDIT_TEXT2 = "View";

// Refresh intervals for different frames (in milliseconds)
const refreshIntervals = {
  'default': 1000
};

// List of live files that handle their own refreshing
const liveFiles = [
  '/frames/live/iO',
  '/frames/live/lampCards',
  '/frames/live/manPanel',
  '/frames/live/siteView',
  '/frames/maint/software',
  '/frames/maint/CATS',
  'report01.html',
  '/frames/setup/configManager'
];

// Helper functions
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function isLiveFile(datapage) {
  return liveFiles.includes(datapage);
}

function getRefreshInterval(datapage) {
  if (isLiveFile(datapage)) {
    return Infinity;
  }
  if (refreshIntervals[datapage]) {
    return refreshIntervals[datapage];
  }
  for (let key in refreshIntervals) {
    if (datapage.startsWith(key.split('/').slice(0, -1).join('/'))) {
      return refreshIntervals[key];
    }
  }
  return refreshIntervals['default'];
}

// Server health check with relative paths
async function checkServerHealth() {
  try {
    const controller = new AbortController();
    const response = await fetch('/hvi?file=/frames/home/homePage', {
      cache: 'no-store',
      signal: controller.signal,
    });
    //console.log(`Server health check: Status ${response.status}`);
    return response.ok;
  } catch (error) {
    //console.warn('Server health check: Error', error.message);
    // Fallback to root endpoint
    try {
      const controller = new AbortController();
      const response = await fetch('/', {
        cache: 'no-store',
        signal: controller.signal,
      });
      //console.log(`Server health check (fallback): Status ${response.status}`);
      return response.ok;
    } catch (fallbackError) {
      //console.warn('Server health check (fallback): Error', fallbackError.message);
      return false;
    }
  }
}

async function openFaultHelpWindow() {
  const width = 1200;
  const height = 800;
  const left = Math.round((screen.width - width) / 2);
  const top = Math.round((screen.height - height) / 2);
  const faultWindow = window.open('', 'FaultCodes', `width=${width},height=${height},scrollbars=yes,resizable=yes,left=${left},top=${top}`);

  try {
    const response = await fetch('/frames/log/faultHelp', { cache: 'no-store' });
    if (!response.ok) throw new Error('Failed to load fault codes');
    const content = await response.text();
    faultWindow.document.write(content);
    faultWindow.focus();
  } catch (error) {
    faultWindow.document.write(`
      <html>
        <head><title>Error</title></head>
        <body>
          <h1>Error Loading Fault Codes</h1>
          <p>${error.message}</p>
        </body>
      </html>
    `);
    faultWindow.focus();
  }
}

async function openNotesWindow() {
  const width = 1200;
  const height = 400;
  const left = Math.round((screen.width - width) / 2);
  const top = Math.round((screen.height - height) / 2);
  const notesWindow = window.open('', 'ConfigurationNotes', `width=${width},height=${height},scrollbars=yes,resizable=yes,left=${left},top=${top}`);
  
  const url = `configNotes?_=${new Date().getTime()}`;
  
  try {
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) throw new Error('Failed to fetch notes');
    const content = await response.text();
    notesWindow.document.write(`
      <html>
        <head>
          <title>Configuration Notes</title>
          <style>
            body { font-family: Consolas, monospace; font-size: 14px; background: #FDFDFD; color: #000; margin: 0; padding: 10px; }
            .header { background: #006BAC; color: #FDFDFD; padding: 5px 10px; font-size: 16px; display: flex; justify-content: space-between; align-items: center; }
            .content { height: 340px; overflow: auto; white-space: pre-wrap; }
            .close-btn { background: none; border: none; color: #FDFDFD; font-size: 14px; cursor: pointer; }
          </style>
        </head>
        <body>
          <div class="header">
            <span>Configuration Notes</span>
            <button class="close-btn" onclick="window.close()">×</button>
          </div>
          <div class="content" id="textContent">${content}</div>
        </body>
      </html>
    `);
    notesWindow.focus();
  } catch (error) {
    notesWindow.document.write(`
      <html>
        <head>
          <title>Configuration Notes</title>
          <style>
            body { font-family: Consolas, monospace; font-size: 14px; background: #FDFDFD; color: #000; margin: 0; padding: 10px; }
            .header { background: #006BAC; color: #FDFDFD; padding: 5px 10px; font-size: 16px; display: flex; justify-content: space-between; align-items: center; }
            .close-btn { background: none; border: none; color: #FDFDFD; font-size: 14px; cursor: pointer; }
          </style>
        </head>
        <body>
          <div class="header">
            <span>Configuration Notes</span>
            <button class="close-btn" onclick="window.close()">×</button>
          </div>
          <div class="content">Error loading notes: ${error.message}</div>
        </body>
      </html>
    `);
    notesWindow.focus();
  }
}

// Initialization
let isInitialized = false;
let lastInitTime = 0;
const INIT_DEBOUNCE_MS = 1000; // Prevent rapid init calls

window.onload = async function () {
  const now = Date.now();
  if (!isInitialized && (now - lastInitTime > INIT_DEBOUNCE_MS)) {
    isInitialized = true;
    lastInitTime = now;
    await init();
  }
};

async function init() {
  if (checkBrowserMode() === 0) {
    // Prevent multiple pop-ups with DOM check
    if (
      typeof alert_msg !== 'undefined' &&
      alert_msg &&
      !document.querySelector('.custom-alert')
    ) {
      // Create a custom alert div
      const alertDiv = document.createElement('div');
      alertDiv.className = 'custom-alert';
      alertDiv.style.cssText = `
        position: fixed;
        top: 50%; /* Center vertically */
        left: 50%;
        transform: translate(-50%, -50%); /* Center both axes */
        width: 50%; /* 50% wide */
        height: 25vh; /* 25% of viewport height */
        background: #ff0000; /* Bright red */
        border: 4px solid #006BAC; /* Primary border */
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        z-index: 1000;
        text-align: center;
        font-family: Arial, sans-serif;
        opacity: 0; /* Start invisible for fade-in */
        transition: opacity 0.3s; /* Smooth fade */
        display: flex; /* Center text vertically */
        align-items: center; /* Center text vertically */
        justify-content: center; /* Center text horizontally */
      `;
      const alertText = document.createElement('strong');
      alertText.style.cssText = `
        color: #FFFFFF; /* Black text */
        font-size: 24px;
        font-weight: strong;
      `;
      alertText.textContent = alert_msg;
      alertDiv.appendChild(alertText);
      document.body.appendChild(alertDiv);

      // Fade in immediately
      setTimeout(() => alertDiv.style.opacity = '1', 0);

      // Fade out and remove after ~3 seconds
      setTimeout(() => {
        alertDiv.style.opacity = '0'; // Fade out
        setTimeout(() => alertDiv.remove(), 300); // Remove after fade
      }, 2700);
    }
    title = null;
    subtitle = null;
    edit = 0;
    min_items = 0;
    max_items = 0;
    refresh = 1; // Default to refresh enabled
    top.refresh = 1;
    const pageUrl = getPageUrl(3);
    if (!pageUrl.includes('file=')) {
      //console.error('init: Invalid page URL, missing file parameter');
      return;
    }

    // Check for extension-related runtime errors
    if (typeof chrome !== 'undefined' && chrome.runtime?.lastError) {
      //console.warn('Detected chrome.runtime.lastError:', chrome.runtime.lastError);
      chrome.runtime.lastError = null;
    }

    // Delay if network is offline
    if (!navigator.onLine) {
      //console.warn('Network offline, delaying initial fetch');
      await sleep(2000);
    }

    // Wait for server to be ready
    const healthRetries = 3;
    let healthRetryCount = 0;
    while (!(await checkServerHealth()) && healthRetryCount < healthRetries) {
      //console.warn(`Server not ready (health check attempt ${healthRetryCount + 1}/${healthRetries})`);
      await sleep(500);
      healthRetryCount++;
    }
    if (healthRetryCount >= healthRetries) {
      console.error('Server health check failed after all attempts');
    } else {
      //console.log('Server is ready, proceeding with fetch');
    }

    // Robust retry mechanism
    const maxRetries = 3;
    let retryCount = 0;
    let success = false;
    const waitForFrame = async () => {
      return new Promise(resolve => {
        if (top.content_frame && top.content_frame.document.readyState === 'complete') {
          //console.log('content_frame readyState: complete');
          resolve();
        } else {
          //console.log('content_frame not ready, polling...');
          const checkFrame = setInterval(() => {
            if (top.content_frame && top.content_frame.document.readyState === 'complete') {
              //console.log('content_frame readyState: complete (polled)');
              clearInterval(checkFrame);
              resolve();
            }
          }, 100);
          setTimeout(() => {
            //console.log('Frame check timeout, proceeding');
            clearInterval(checkFrame);
            resolve(); // Fallback after 5s
          }, 5000);
        }
      });
    };

    while (retryCount < maxRetries && !success) {
      //console.log(`Attempting initial load (attempt ${retryCount + 1}/${maxRetries})`);
      try {
        await waitForFrame();
        await loadPage(pageUrl);
        // Validate http_buffer before proceeding
        if (!http_buffer || typeof http_buffer !== 'string') {
          throw new Error('Invalid http_buffer after loadPage');
        }
        // Set refresh based on edit mode after loading config
        if (edit === 1) {
          //console.log('Setting edit mode: refresh = 0, re-rendering data');
          refresh = 0;
          top.refresh = 0;
          getConfig();
          printData();
          // Update inst_frame button
          if (top.frames['inst_frame']?.doInit) {
            top.frames['inst_frame'].doInit();
          }
        }
        // Always update inst_frame button
        if (top.frames['inst_frame']?.doInit) {
          top.frames['inst_frame'].doInit();
        } else {
          //console.warn('init: inst_frame not available, retrying in 500ms');
          setTimeout(() => top.frames['inst_frame']?.doInit?.(), 500);
        }
        success = true;
        //console.log('Initial load successful, starting refresh cycle');
        startRefreshCycle();
      } catch (error) {
        //console.error(`Initial load failed (attempt ${retryCount + 1}/${maxRetries}):`, error);
        retryCount++;
        if (retryCount < maxRetries) {
          await sleep(500);
        }
      }
    }
    if (!success) {
      //console.error('All initial load attempts failed. Relying on refresh cycle.');
      startRefreshCycle();
    }
  } else {
    const errorDiv = document.createElement('div');
    errorDiv.innerHTML = `<h2>This browser is not supported!</h2> (${err})`;
    document.body.appendChild(errorDiv);
  }
}

function getPageUrl(pageId) {
  const pageMap = {
    3: '/hvi?file=editor/parseData&uic=3145&page=/frames/home/homePage',
  };
  return pageMap[pageId] || '/hvi?file=editor/parseData&uic=3145&page=/frames/home/homePage';
}

async function startRefreshCycle() {
  if (isLiveFile(datapage)) return;
  while (true) { // Run indefinitely
    if (refresh === 1 && http_status === 0) {
      try {
        //console.log('startRefreshCycle: Attempting to load page:', datapage);
        await loadPage(1);
        //console.log('startRefreshCycle: Page load successful');
      } catch (error) {
        //console.error('Refresh failed:', error);
      }
    }
    await sleep(getRefreshInterval(datapage));
  }
}

async function loadPage(p) {
  if (top.viewmode === 0) {
    await makeHttpRequestAsync(`/hvi?file=${datapage}&pos1=${pos1}&pos2=${pos2}`, "bufferPage", p);
  } else {
    await makeHttpRequestAsync(`/hvi?file=${datapage}`, "bufferPage", p);
  }
}

function bufferPage(p, page) {
  if (typeof page !== 'string' || page.startsWith('Error:') || page.trim() === '') {
    //console.warn('bufferPage: Invalid or empty page data', page);
    http_buffer = '';
    return;
  }
  http_buffer = page;
  lastValidHttpBuffer = page; // Store valid data
  if (p === 1) {
    printData();
  } else if (p === 2) {
    getConfig();
  } else {
    if (getConfig() === 1 && !hasLoadedPage) {
      hasLoadedPage = true;
      loadPage(3);
    } else {
      hasLoadedPage = false;
      printData();
    }
  }
}

// Global object to track failed attempts per URL
const failedAttempts = {};

// Maximum number of total attempts (including retries) before stopping
const MAX_TOTAL_ATTEMPTS = 5;
const alertShown = {};

async function makeHttpRequestAsync(url, callback_function, callback_parameters, return_xml) {
  if (!failedAttempts[url]) {
    failedAttempts[url] = 0;
  }

  if (failedAttempts[url] >= MAX_TOTAL_ATTEMPTS) {
    if (!alertShown[url]) {
      console.warn(`Stopped requesting ${url}: Maximum attempts (${MAX_TOTAL_ATTEMPTS}) reached.`);
      alert(`Unable to connect to PTC-1 after ${MAX_TOTAL_ATTEMPTS} attempts.\nPlease check Connection / Controller.`);
      alertShown[url] = true; // Mark alert as shown
    }
    http_status = 0;
    window[callback_function](callback_parameters, `Error: Maximum attempts reached`);
    loadPageIndicator(0);
    return;
  }

  //console.log('Initiating fetch for:', url);
  if (!url || url.includes('file=&') || !url.startsWith('/hvi')) {
    //console.error('makeHttpRequestAsync: Invalid URL:', url);
    http_status = 0;
    window[callback_function](callback_parameters, 'Error: Invalid URL');
    loadPageIndicator(0);
    return;
  }

  const optionalFiles = ['customPage', 'layout.txt', 'report01.html'];
  const isOptional = optionalFiles.some(file => url.includes(file));
  const cacheBustUrl = url.includes('?') ? `${url}&_=${new Date().getTime()}` : `${url}?_=${new Date().getTime()}`;

  const maxRetries = 2;
  let retryCount = 0;
  let lastError = null;

  while (retryCount <= maxRetries) {
    if (abortController) {
      abortController.abort();
    }
    abortController = new AbortController();

    loadPageIndicator(1);
    http_status = 1;

    try {
      const response = await fetch(cacheBustUrl, {
        method: 'GET',
        cache: 'no-store',
        signal: abortController.signal,
      });

      //console.log(`Fetch response for ${url}: Status ${response.status}, Headers:`, response.headers);

      if (!response.ok) {
        if (isOptional && response.status === 404) {
          //console.log(`Optional file ${url} not found, continuing...`);
          http_status = 0;
          window[callback_function](callback_parameters, '');
          return;
        }
        throw new Error(`HTTP error ${response.status}: ${response.statusText} for URL: ${cacheBustUrl}`);
      }

      const data = await response.text();
      if (!data && !isOptional) {
        throw new Error(`Empty response from server for URL: ${cacheBustUrl}`);
      }

      // Reset failed attempts on success
      failedAttempts[url] = 0;
      http_status = 0;
      window[callback_function](callback_parameters, data || '');
      return;
    } catch (error) {
      if (error.name === 'AbortError') {
        //console.log('Fetch aborted:', url);
        return;
      }
      lastError = error;
      //console.error(`makeHttpRequestAsync: Fetch error (attempt ${retryCount + 1}/${maxRetries + 1}):`, error, 'URL:', url, 'Navigator online:', navigator.onLine);
      retryCount++;
      failedAttempts[url]++; // Increment failed attempts
      if (retryCount <= maxRetries) {
        //console.log(`Retrying fetch for ${url} in 500ms...`);
        await sleep(500);
      }
    } finally {
      loadPageIndicator(0);
      abortController = null;
    }
  }

  //console.error('makeHttpRequestAsync: All retries failed:', lastError, 'URL:', url);
  http_status = 0;
  window[callback_function](callback_parameters, isOptional ? '' : `Error: ${lastError.message}`);
}

function getConfig() {
  title = null;
  subtitle = null;
  max_items = 0;
  min_items = 0;
  edit = 0;

  if (!http_buffer || typeof http_buffer !== 'string') {
    //console.warn('getConfig: http_buffer is invalid', http_buffer);
    return 0;
  }

  const data_array = http_buffer.split('\n');
  loadPageIndicator(0);

  if (top.viewmode === 0) {
    buttons = 1;
  } else {
    buttons = top.buttons || 0;
    // Only set refresh from top.refresh if not already set
    if (refresh === 1) {
      refresh = top.refresh || 0;
    }
  }

  for (const line of data_array) {
    const item_array = line.split(';');
    switch (item_array[0]) {
      case ':TITLE':
        title = item_array[1];
        break;
      case ':SUBTITLE':
        subtitle = item_array[1];
        break;
      case ':MAX':
        max_items = parseInt(item_array[1]);
        break;
      case ':MIN':
        min_items = parseInt(item_array[1]);
        break;
      case ':EDIT':
        edit = parseInt(item_array[1]);
        break;
      case ':REFRESH':
        if (top.viewmode === 0) refresh = parseInt(item_array[1]);
        break;
      case ':PCREFRESH':
        if (top.viewmode === 1) refresh = parseInt(item_array[1]);
        break;
      case ':PAGESIZE':
        pagesize = parseInt(item_array[1]);
        break;
    }
  }

  pos1 = min_items;
  pos2 = max_items;

  return 0;
}

let hasLoadedPage = false;

function printData() {
  // Initialize variables
  const dataDiv = document.getElementById('data');
  const textareaDiv = document.getElementById('textarea');
  let output = [];
  let table = null;
  let isTable = false;
  let isTextarea = false;
  let isFirstTextareaLine = true;
  let textareaContent = '';
  const bufferToUse = http_buffer;

  // Validate dataDiv
  if (!dataDiv) {
    //console.warn('printData: data div not found');
    return;
  }

  // Table class definition
  class Table {
    constructor(isMainTable) {
      this.isMainTable = isMainTable;
      this.header = [];
      this.body = [];
      this.edit = [];
      this.format = [];
      this.params = [];
      this.widths = [];
      this.colors = [];
      this.colspans = [];
      this.rowspans = [];
      this.editNameIndex = null;
      this.editIdIndex = null;
      this.headers = []; // Ensure headers is initialized
    }

    addHeader(items) {
      const cells = items.slice(2).map((text, i) => {
        const colIndex = i + 2;
        const width = this.widths[colIndex] ? ` width="${this.widths[colIndex]}"` : '';
        const bgColor = this.colors[colIndex] ? ` style="background-color:${this.colors[colIndex]}"` : '';
        const colspan = this.colspans[colIndex] ? ` colspan="${this.colspans[colIndex]}"` : '';
        const rowspan = this.rowspans[colIndex] ? ` rowspan="${this.rowspans[colIndex]}"` : '';
        const fmt = width + bgColor + colspan + rowspan;
        return `<TH${fmt}>${text}</TH>`;
      }).join('');
      this.header.push(`<TR>${cells}</TR>`);
    }

    addData(items) {
      // Validate items
      if (!Array.isArray(items) || items.length < 2) {
        //console.warn('addData: Invalid items array', items);
        return;
      }
      const cells = items.slice(2).map((text, i) => {
        const colIndex = i + 2;
        const width = this.widths[colIndex] ? ` width="${this.widths[colIndex]}"` : '';
        const bgColor = this.colors[colIndex] ? ` style="background-color:${this.colors[colIndex]}"` : '';
        const colspan = this.colspans[colIndex] ? ` colspan="${this.colspans[colIndex]}"` : '';
        const rowspan = this.rowspans[colIndex] ? ` rowspan="${this.rowspans[colIndex]}"` : '';
        const fmt = width + bgColor + colspan + rowspan;
        if (this.edit[colIndex] === 'U' && refresh === 0) {
          const param = this.params[colIndex] || '';
          const id = this.editIdIndex ? items[this.editIdIndex] || '' : '';
          const header = this.headers[colIndex] || '';
          const name = this.editNameIndex ? items[this.editNameIndex] || '' : '';
          if (this.format[colIndex] === 'UF') {
            const onclick = `doUserFunction("${param}","${id}")`;
            if (buttons) {
              return `<TD${fmt} class="edit"><BUTTON type="button" onclick='${onclick}'>${text || ''}</BUTTON></TD>`;
            }
            return `<TD${fmt} class="edit" onclick='${onclick}'>${text || ''}</TD>`;
          }
          const label = `${header} ${name} = ${text || ''}`;
          const onclick = `doEdit("${label}","${param}/${id}","${this.format[colIndex] || ''}")`;
          if (buttons) {
            return `<TD${fmt} class="edit"><BUTTON type="button" onclick='${onclick}'>${text || ''}</BUTTON></TD>`;
          }
          return `<TD${fmt} class="edit" onclick='${onclick}'>${text || ''}</TD>`;
        }
        return `<TD${fmt}>${text || ''}</TD>`;
      }).join('');
      this.body.push(`<TR>${cells}</TR>`);
    }

    toHTML() {
      const thead = this.header.length ? `<THEAD>${this.header.join('')}</THEAD>` : '';
      const tbody = this.body.length ? `<TBODY>${this.body.join('')}</TBODY>` : '';
      return `<TABLE>${thead}${tbody}</TABLE><BR>`;
    }
  }

  // Validate http_buffer
  if (!bufferToUse || typeof bufferToUse !== 'string') {
    //console.warn('printData: http_buffer is invalid', bufferToUse);
    dataDiv.innerHTML = '';
    return;
  }

  // Process buffer lines
  const lines = bufferToUse.split('\n');
  for (const line of lines) {
    if (!line.startsWith(':')) {
      if (line && !isTable && !isTextarea) {
        output.push(line);
      } else if (isTextarea && line) {
        textareaContent += isFirstTextareaLine ? line : `<br>${line}`;
        isFirstTextareaLine = false;
      }
      continue;
    }

    const items = line.split(';');
    const directive = items[0];

    switch (directive) {
      case ':BEGINTABLE':
        table = new Table(false);
        isTable = true;
        break;
      case ':BEGINMAINTABLE':
        table = new Table(true);
        isTable = true;
        break;
      case ':ENDTABLE':
      case ':ENDMAINTABLE':
        if (table) {
          output.push(table.toHTML());
          table = null;
          isTable = false;
        }
        break;
      case ':BEGINTEXTAREA':
        isTextarea = true;
        isFirstTextareaLine = true;
        textareaContent = '';
        break;
      case ':ENDTEXTAREA':
        isTextarea = false;
        if (textareaDiv) {
          textareaDiv.innerHTML = textareaContent;
          textareaDiv.scrollTop = textareaDiv.scrollHeight;
        }
        break;
      case ':E':
        if (table) {
          table.edit = items;
          for (let i = 1; i < items.length; i++) {
            if (items[i - 1] === 'N') table.editNameIndex = i - 1;
            if (items[i - 1] === 'I') table.editIdIndex = i - 1;
          }
        }
        break;
      case ':F':
        if (table) table.format = items;
        break;
      case ':P':
        if (table) table.params = items;
        break;
      case ':W':
        if (table) table.widths = items;
        break;
      case ':C':
        if (table) table.colors = items;
        break;
      case ':S':
        if (table) table.colspans = items;
        break;
      case ':R':
        if (table) table.rowspans = items;
        break;
      case ':H':
        if (table) table.addHeader(items);
        break;
      case ':D':
      case '%:D':
        if (table) table.addData(items);
        break;
    }
  }

  // Render output
  requestAnimationFrame(() => {
    dataDiv.innerHTML = output.join('');
    if (title) document.getElementById('title').innerHTML = `<span style="color: #006BAC;">${title}</span>`;
    if (subtitle) document.getElementById('title2').innerHTML = subtitle;
    if (textareaDiv && textareaContent) {
      textareaDiv.innerHTML = textareaContent;
      textareaDiv.scrollTop = textareaDiv.scrollHeight;
    }
  });
}

function doDbWrite(parname, val) {
  document.settingstable.edit_caption.value = title || '';
  document.settingstable.edit_label.value = val || '';
  document.settingstable.edit_par.value = parname;
  document.settingstable.edit_file.value = "editor/dbWrite";
  savePagePosition();
  document.settingstable.submit();
}

function doHideRows(parname, val) {
  document.settingstable.edit_caption.value = title || '';
  document.settingstable.edit_label.value = val || '';
  document.settingstable.edit_par.value = parname;
  document.settingstable.edit_file.value = "editor/dbWrite";
  savePagePosition();
  document.settingstable.submit();
}

function doEdit(label, parname, format) {
  document.settingstable.edit_caption.value = title || '';
  document.settingstable.edit_label.value = label || '';
  document.settingstable.edit_par.value = parname;
  document.settingstable.edit_format.value = format;
  document.settingstable.edit_file.value = "/editor/mainEdit";
  savePagePosition();
  if (edit === 1) {
    top.dp_refresh = 0; // Restore edit mode after submission
  }
  document.settingstable.submit();
}

function doEdit2(label, parname, format) {
  document.settingstable.edit_caption.value = title || '';
  document.settingstable.edit_label.value = label || '';
  document.settingstable.edit_par.value = parname;
  document.settingstable.edit_format.value = format;
  document.settingstable.edit_file.value = "/editor/reboot";
  savePagePosition();
  document.settingstable.submit();
}

function doUserFunction(uf, val) {
  savePagePosition();
  if (val) {
    top.doUFHref(datapage, uf, val);
  } else {
    top.doUFHref(datapage, uf);
  }
}

function openTextModal() {
  const modal = document.getElementById('textModal');
  const backdrop = document.getElementById('modalBackdrop');
  const textContent = document.getElementById('textContent');
  
  if (modal && backdrop && textContent) {
    modal.style.display = 'block';
    backdrop.style.display = 'block';
  
    fetch('configNotes')
      .then(response => {
        if (!response.ok) throw new Error('File not found');
        return response.text();
      })
      .then(data => {
        textContent.textContent = data;
      })
      .catch(error => {
        textContent.textContent = 'Error loading file: ' + error.message;
      });
  } else {
    //console.error('Modal elements not found');
  }
}

function closeTextModal() {
  const modal = document.getElementById('textModal');
  const backdrop = document.getElementById('modalBackdrop');
  if (modal && backdrop) {
    modal.style.display = 'none';
    backdrop.style.display = 'none';
  }
}

function savePagePosition() {
  top.dp_datapage = datapage;
  top.dp_editpos = editpos;
  top.dp_refresh = refresh;
  top.dp_scroll_line = window.pageYOffset;
}

function loadPagePosition() {
  if (top.dp_datapage === datapage) {
    editpos = top.dp_editpos;
    if (top.dp_refresh !== null) {
      refresh = top.dp_refresh;
      top.refresh = refresh;
      // Update inst_frame button
      if (top.frames['inst_frame']?.doInit) {
        top.frames['inst_frame'].doInit();
      }
    }
  } else {
    clearPagePosition();
  }
}

function clearPagePosition() {
  top.dp_datapage = "";
  top.dp_editpos = null;
  top.dp_refresh = null;
  top.dp_scroll_line = null;
}

function loadScrollPosition() {
  if (top.dp_datapage === datapage && top.dp_scroll_line != null) {
    requestAnimationFrame(() => {
      window.scrollTo({ top: top.dp_scroll_line, behavior: 'smooth' });
    });
  }
}

function loadPageIndicator(s) {
  const loadDiv = top.frames['inst_frame']?.document.getElementById('loadind');
  if (loadDiv) {
    requestAnimationFrame(() => {
      loadDiv.style.backgroundColor = s ? '#00c700' : '#DDDDDD';
    });
  }
}

function checkBrowserMode() {
  err = 0;
  if (!document.getElementById) {
    err = 1;
  }
  if (!window.fetch) {
    err = 2;
  }
  if (parent === self) {
    top.location.href = "index.html";
  }
  if (!top.historyArray?.[0]) {
    top.doDataHref('/frames/home/homePage', 0);
  }
  return err;
}

// Utility function
function translate(text) {
  return text; // Replace with actual translation logic
}

// Cookie utility
function getCookie(name) {
  return null; // Replace with actual cookie logic
}