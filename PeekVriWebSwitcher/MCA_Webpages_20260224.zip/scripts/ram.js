function getTM1XDescription(code) {
  const match = code.match(/^TM1X(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 16) {
      return `Maximum Green - Set ${number}`;
    }
  }
  return null;
}

function getTM2XDescription(code) {
  const match = code.match(/^TM2X(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 16) {
      return `Alternative Maximum Green - Set ${number}`;
    }
  }
  return null;
}

function getTPMGDescription(code) {
  const match = code.match(/^TPMG(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 16) {
      return `PSVP Maximum Green - Set ${number}`;
    }
  }
  return null;
}

function getTPIDescription(code) {
  const match = code.match(/^TPI(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 16) {
      return `PSVP Inhibit Time - Set ${number}`;
    }
  }
  return null;
}

function getTPCDescription(code) {
  const match = code.match(/^TPC(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 16) {
      return `PSVP Compensation Time - Set ${number}`;
    }
  }
  return null;
}

function getCLFIADescription(code) {
  const match = code.match(/^CLFIA(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 32) {
      return `CLF Stage - Plan ${number}`;
    }
  }
  return null;
}

function getCLFIFDescription(code) {
  const match = code.match(/^CLFIF(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 32) {
      return `CLF Influence - Plan ${number}`;
    }
  }
  return null;
}

function getCLFTDescription(code) {
  const match = code.match(/^CLFT(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 32) {
      return `CLF Influence Time - Plan ${number}`;
    }
  }
  return null;
}

function getCLFXDescription(code) {
  const match = code.match(/^CLFX(\d+)$/);
  if (match) {
    const number = parseInt(match[1], 10);
    if (number >= 1 && number <= 32) {
      return `CLF Stream Number - Plan ${number}`;
    }
  }
  return null;
}

function phd(value) {
  const phdName = [
    { value: 0, name: 'None' },
    { value: 1, name: 'Gain (intergrn+)' },
    { value: 2, name: 'Gain (end stage+)' },
    { value: 3, name: 'Gain (start grn+)' },
    { value: 4, name: 'Gain (end red+)' },
    { value: 11, name: 'Lose (end stage+)' },
    { value: 12, name: 'Lose (end green+)' }
  ];
  const match = phdName.find(entry => entry.value === parseInt(value, 10));
  return match ? match.name : value.toString();
}

function mtcf(value) {
  const mtcFUNC = [
    { value: 0, name: 'None' },
    { value: 1, name: 'PTC1 Control App' },
    { value: 2, name: 'Max Set' },
    { value: 3, name: 'Part Time' },
    { value: 4, name: 'CLF Plan' },
    { value: 5, name: 'Isolate' },
    { value: 6, name: 'Audible' }
  ];
  const parsedValue = parseInt(value, 10);
  if (!isNaN(parsedValue)) {
    if (parsedValue >= 7 && parsedValue <= 31) {
      return `User Function ${parsedValue - 6}`;
    }
    const match = mtcFUNC.find(entry => entry.value === parsedValue);
    if (match) {
      return match.name;
    }
  }
  return value.toString();
}

function parseSpecialDate(value) {
  const parsedValue = parseInt(value, 10);
  if (!isNaN(parsedValue)) {
    if (parsedValue === 0) {
      return "0";
    }
    const strValue = parsedValue.toString().padStart(6, '0');
    if (strValue.length === 6) {
      const year = strValue.slice(0, 2);
      const month = strValue.slice(2, 4);
      const day = strValue.slice(4, 6);
      if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
        return `${day}/${month}/20${year}`;
      }
    }
  }
  return value.toString();
}

function phdValueToLetter(value) {
  const parsedValue = parseInt(value, 10);
  if (!isNaN(parsedValue)) {
    if (parsedValue === -1) {
      return 'None';
    }
    if (parsedValue >= 0 && parsedValue <= 25) {
      return String.fromCharCode(65 + parsedValue);
    }
  }
  return value.toString();
}

function clf(value) {
  const clf_INF = [
    { value: 0, name: 'None' },
    { value: 1, name: 'IM' },
    { value: 2, name: 'DD' },
    { value: 3, name: 'PX' },
    { value: 4, name: 'ISOL' },
    { value: 5, name: 'HS' },
    { value: 6, name: 'Standalone - Hold Vehicle' },
    { value: 7, name: 'Standalone - Hold Ped' }
  ];
  const match = clf_INF.find(entry => entry.value === parseInt(value, 10));
  return match ? match.name : value.toString();
}

function dfmState(value) {
  const dfm = [
    { value: 0, name: 'User Input' },
    { value: 1, name: 'Inactive' },
    { value: 2, name: 'Active' }
  ];
  const match = dfm.find(entry => entry.value === parseInt(value, 10));
  return match ? match.name : value.toString();
}

function clfSync(value) {
  const clf_Sync = [
    { value: 0, name: 'Daily' },
    { value: 1, name: 'Weekly' },
    { value: 2, name: 'Start' },
    { value: 3, name: 'Continuous' }
  ];
  const match = clf_Sync.find(entry => entry.value === parseInt(value, 10));
  return match ? match.name : value.toString();
}

function convertDays(value) {
  const daysMap = [
    { value: 1, name: 'Mon' },
    { value: 2, name: 'Tue' },
    { value: 4, name: 'Wed' },
    { value: 8, name: 'Thu' },
    { value: 16, name: 'Fri' },
    { value: 32, name: 'Sat' },
    { value: 64, name: 'Sun' }
  ];
  const days = daysMap
    .filter(day => (value & day.value) === day.value)
    .map(day => day.name);
  return days.length > 0 ? days.join(',') : value.toString();
}

function convertDFUNC(value) {
  const detFuncMap = [
    { value: 1, name: 'Dem' },    // Bit 0
    { value: 2, name: 'Ext' },    // Bit 1
    { value: 8, name: 'Cancel' }  // Bit 3
  ];

  // Handle value = 0 explicitly
  if (value === 0) {
    return 'None';
  }

  // Process bitmask for value > 0
  const detFunc = detFuncMap
    .filter(detFunc => (value & detFunc.value) === detFunc.value)
    .map(detFunc => detFunc.name);

  // Return joined names if matches found, otherwise return value as string
  return detFunc.length > 0 ? detFunc.join(',') : value.toString();
}

function otu(value) {
  const otuMap = [
    { value: 1, name: 'Control' },
    { value: 2, name: 'Reply' }
  ];
  const otus = otuMap
    .filter(otus => (value & otus.value) === otus.value)
    .map(otus => otus.name);
  return otus.length > 0 ? otus.join(',') : value.toString();
}

const divideLookup = {
  R1: 1,
  R2: 10,
  R20: "R20",
  R21: "R21",
  R11: "R11",
  R10: "R10",
  undefined: 0
};

const descriptionLookup = {
  TG: "Minimum Green",
  TGR: "Minimum Red",
  TING: "Intergreen",
  TSDE: "SDE Curtail Value",
  TEX1: "Forced Change Extension",
  FCCERM: "Conflict Extension Red",
  PCMMAP: "Period 5",
  PCAMAP: "Period 6",
  TLAR: "Period 7",
  TSAR: "Period 8",
  TPAR: "Pedestrian Period 8",
  TPDF: "Pelican Period E",
  TPVF: "Pelican Period F",
  TVFL: "Pelican Period G",
  TPBT: "Pedestrian Blackout Period",
  PHDPH: "Phase Delay PHASE",
  PHDFSTG: "Phase Delay FROM Stage",
  PHDTSTG: "Phase Delay TO Stage",
  PHDTIME: "Phase Delay TIME",
  XDET: "Detector Overide - where 1=Off, 2=On",
  DTG1: "Detector Extension",
  DTO: "Detector Call Delay",
  DTC: "Detector Cancel Delay",
  XDETENA: "Detector DFM",
  XDETINV: "Detector Software Inverted",
  DFUNC: "Detector Functions",
  XDETO: "DFM Active Time - Set 1",
  XDETN: "DFM Inactive Time - Set 1",
  XDETAO: "DFM Active Time - Set 2",
  XDETAN: "DFM Inactive Time - Set 2",
  XDETBO: "DFM Active Time - Set 3",
  XDETBN: "DFM Inactive Time - Set 3",
  XDETCO: "DFM Active Time - Set 4",
  XDETCN: "DFM Inactive Time - Set 4",
  MTCF: "Timetable Function",
  MTCA1: "Timing set ARG1 Value",
  MTCD: "Timetable Entry Day Map",
  PHDTYPE: "Phase Delay Type",
  MTCTS: "Timetable Entry Start Time",
  MTCTE: "Timetable Entry End Time",
  CLFCY: "CLF Plan Cycle Time",
  EVP1: "Event Pulse ON Time",
  EVP2: "Event Pulse OFF Time",
  PARM: "Software Switch",
  GPTM: "GP Timer Reference Value",
  XLMU: "Lamp Monitor [P1 - Watts per Lamp]",
  XLMD: "Lamp Monitor [P2 - Watts per Lamp]",
  TS: "Forced Timing Set",
  UP: "Generic Parameter",
  TSON: "Starting Intergreen",
  TEX2: "RLM Additional IGN",
  XDETOK: "Detector OK Count",
  XDETERC: "DFM Fail State",
  XOTUI: "OTU Control/Reply Invert",
  MTCYD: "Timetable Special Days Date",
  MTCYG: "Timetable Special Days Group",
  CLFREF: "CLF Base Time",
  CLFWDAY: "CLF Base Time Sync Day",
  CLFSYNC: "CLF Base Time Sync Mode",
  CLFEN: "CLF Plan Entry Time",
  CLFEX: "CLF Plan Exit Time",
  CLFOF: "CLF Plan Offset Time",
  HCD: "Hurry Call Delay Time",
  HCH: "Hurry Call Hold Time",
  HCP: "Hurry Call Prevent Time",
  PSVPOT: "PSVP Checkin Timeout",
  PSVPIT: "PSVP Pre Checkin Timeout",
  PSVPOD: "PSVP Checkout Delay",
  PSVPID: "PSVP Checkin Delay",
  PSVPPD: "PSVP Pre Checkin Delay"
};

const r20Lookup = {
  '1': 'OFF',
  '2': 'ON',
  '0': 'NORMAL'
};

const r21Lookup = {
  '0': 'OFF',
  '1': 'ON'
};

window.parseRAM = function parseRAM() {
  try {
    let ramData = [];
    const xhr = new XMLHttpRequest();
    xhr.open('GET', './part/XPAR.STS', false);
    xhr.send();
    if (xhr.status !== 200) {
      throw new Error('Failed to load XPAR.STS');
    }
    ramData = xhr.responseText.trim().split('\n').map(line => {
      const parts = line.split(/\s+/);
      if (parts.length < 7) {
        //console.warn('Invalid file entry:', line);
        return null;
      }
      const codeParts = parts[4].split(/[\./]/);
      const code = codeParts[0];
      const divideNo = codeParts[1]?.split(',')[0] || '';
      const element = codeParts[2] || parts[4];
      return [
        parts[0], // date
        parts[1], // time
        parts[2], // 3
        parts[3], // 0
        code,     // MTCA1
        parts[4], // Full code (e.g., UP.R1/UTC_FORCE_TIMEOUT)
        '',       // Placeholder
        divideNo, // R1
        element,  // 4 or B,C
        parts[5], // currentVal
        parts[6]  // originalVal
      ];
    }).filter(entry => entry !== null);

    const ramEntries = ramData.length;
    if (ramEntries === 0) {
      alert('No valid data found in XPAR.STS');
      return;
    }

    const formattedData = ramData.map(entry => {
      const date = entry[0] || '';
      const time = entry[1] || '';
      const code = entry[4] || '';
      const divideNo = entry[7] || '';
      let element = entry[8] || 'N/A';
      
      // Handle integer elements: increment by 1 if it's a valid integer
      const parsedElement = parseInt(element, 10);
      if (!isNaN(parsedElement) && element === parsedElement.toString()) {
        element = parsedElement + 1;
      }

      const currentVal = entry[9] || '0';
      const originalVal = entry[10] || '0';
      
      // Parse originalVal, handling parentheses (e.g., "(60)" → 60)
      let parsedOriginal;
      if (originalVal.startsWith('(') && originalVal.endsWith(')')) {
        parsedOriginal = parseInt(originalVal.slice(1, -1), 10);
      } else {
        parsedOriginal = parseInt(originalVal, 10);
      }
      const originalValue = isNaN(parsedOriginal) ? 0 : parsedOriginal;

      let divider = divideLookup[divideNo] || 0;
      let newCurrent = currentVal;
      let newOriginal = originalValue;

      // Handle CLFX codes: increment integer currentVal and originalValue by 1
      if (code.match(/^CLFX\d+$/)) {
        const parsedCurrent = parseInt(currentVal, 10);
        if (!isNaN(parsedCurrent) && currentVal === parsedCurrent.toString()) {
          newCurrent = parsedCurrent + 1;
        }
        if (!isNaN(parsedOriginal) && originalVal.match(/^-?\d+$/)) {
          newOriginal = parsedOriginal + 1;
        }
        divider = 0;
      }

      // Handle CLFIF codes
      if (code.match(/^CLFIF\d+$/)) {
        divider = 0;
        newCurrent = clf(currentVal);
        newOriginal = clf(originalValue);
      }

      if (['EVP1', 'EVP2'].includes(code)) {
        divider = 10;
      }

      if (['MTCD', 'CLFWDAY'].includes(code)) {
        newCurrent = convertDays(parseInt(currentVal));
        newOriginal = convertDays(parseInt(originalValue));
        divider = 0;
      } else if (code === 'DFUNC') {
        divider = 0;
        newCurrent = convertDFUNC(parseInt(currentVal));
        newOriginal = convertDFUNC(parseInt(originalValue));
      } else if (code === 'XOTUI') {
        divider = 0;
        newCurrent = otu(parseInt(currentVal));
        newOriginal = otu(parseInt(originalValue));
      } else if (divider === 'R20') {
        divider = 0;
        newCurrent = r20Lookup[currentVal] || currentVal;
        newOriginal = r20Lookup[originalValue] || originalValue;
      } else if (divider === 'R21') {
        divider = 0;
        newCurrent = r21Lookup[currentVal] || currentVal;
        newOriginal = r21Lookup[originalValue] || originalValue;
      } else if (divider === 'R10') {
        divider = 0;
        newCurrent = formatTime(currentVal, 4);
        newOriginal = formatTime(originalValue, 4);
      } else if (divider === 'R11') {
        divider = 0;
        newCurrent = formatTime(currentVal, 4);
        newOriginal = formatTime(originalValue, 4);
      } else if (code === 'XDETERC') {
        divider = 0;
        newCurrent = dfmState(currentVal);
        newOriginal = dfmState(originalValue);
      } else if (code === 'CLFSYNC') {
        divider = 0;
        newCurrent = clfSync(currentVal);
        newOriginal = clfSync(originalValue);
      } else if (code === 'PHDTYPE') {
        divider = 0;
        newCurrent = phd(currentVal);
        newOriginal = phd(originalValue);
      } else if (code === 'PHDPH') {
        divider = 0;
        newCurrent = phdValueToLetter(currentVal);
        newOriginal = phdValueToLetter(originalValue);
      } else if (code === 'MTCF') {
        divider = 0;
        newCurrent = mtcf(currentVal);
        newOriginal = mtcf(originalValue);
      } else if (code === 'MTCYD') {
        divider = 0;
        newCurrent = parseSpecialDate(currentVal);
        newOriginal = parseSpecialDate(originalValue);
      }

      const description =
        getTM1XDescription(code) ||
        getTM2XDescription(code) ||
		getTPMGDescription(code) ||
		getTPIDescription(code) ||
		getTPCDescription(code) ||
        getCLFTDescription(code) ||
        getCLFIADescription(code) ||
        getCLFIFDescription(code) ||
        getCLFXDescription(code) ||
        descriptionLookup[code] ||
        `${code} *No Matched Text Conversion`;

      return {
        description,
        element,
        current: divider ? (newCurrent / divider) : newCurrent,
        original: divider ? (newOriginal / divider) : newOriginal,
        date,
        time
      };
    });

    showPopup(formattedData, ramData);
  } catch (error) {
    //console.error('Error processing RAM data:', error);
    alert('Error processing data: ' + error.message);
  }
};

function formatTime(value, digits) {
  const padded = String(value).padStart(digits, '0');
  if (digits === 4) {
    return `${padded.slice(0, 2)}:${padded.slice(2, 4)}`;
  }
  return `${padded.slice(0, 2)}:${padded.slice(2, 4)}:${padded.slice(4, 6)}`;
}

function downloadScript(scriptText) {
  const blob = new Blob([scriptText], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'PTC1Script.txt';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function showPopup(formattedData, ramData) {
  // Generate script text from ramData
  const scriptLines = [
    'CONNECT',
    'Break',
    '@lo 3145',
    ...ramData.map(entry => `@wr ${entry[5]} ${entry[9]}`),
    'exit'
  ];
  const scriptText = scriptLines.join('\n');

  const popup = window.open('', 'RAM Data', 'width=1600,height=800');
  popup.document.write(`
    <html>
      <head>
        <title>PTC-1 RAM Data [ Translated ]</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; margin: 0; background-color: #efefef; }
          .table-container { max-height: 600px; overflow-y: auto; width: 100%; }
          table { border-collapse: collapse; width: 100%; }
          th, td { border: 2px solid #006BAC; padding: 6px; text-align: left; height: 20px; }
          th { background-color: #006BAC; color: white; position: sticky; top: 0; z-index: 10; }
          button { margin-top: 10px; padding: 8px 16px; }
          li { list-style: none; }
          textarea { width: 100%; height: 150px; margin-top: 10px; font-family: monospace; }
        </style>
        <script>
          function downloadScript(scriptText) {
            const blob = new Blob([scriptText], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'PTC1Script.txt';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }
        </script>
      </head>
      <body>
        <div class="table-container">
          <table>
            <tr>
              <th>Date</th>
              <th>Time</th>
              <th>Parameter</th>
              <th>Row Index / Name</th>
              <th>New Value</th>
              <th>Initial Value</th>
            </tr>
            ${formattedData.map(row => `
              <tr>
                <td>${row.date}</td>
                <td>${row.time}</td>
                <td>${row.description}</td>
                <td>${row.element}</td>
                <td>${row.current}</td>
                <td>${row.original}</td>
              </tr>
            `).join('')}
          </table>
        </div>
        <ul style="display: flex; justify-content: space-between; list-style: none; padding: 0;">
		  <li>
			<button type="button" style="background-color: #006BAC; color: white;" onclick="window.print()">Print To File</button>
		  </li>
		  <li>
			<button type="button" style="background-color: #006BAC; color: white;" onclick="downloadScript(\`${scriptText.replace(/`/g, '\\`')}\`)">Save Communicator Script</button>
		  </li>
		  <li>
			<button type="button" style="background-color: #006BAC; color: white;" onclick="window.close()">Close Window</button>
		  </li>
		</ul>
      </body>
    </html>
  `);
}