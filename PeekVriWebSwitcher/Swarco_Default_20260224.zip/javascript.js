﻿var datapage = "m001.hvi";
var pagesize = 25;
var refresh = 1;
var buttons = 0; 

var pos1 = 0;
var pos2 = pagesize - 1;
var tijd;
var maxpage = 1;
var page = 0;
var lastpagesize = 0;
var editpos = 0;

var helpwindow_id;

//Load data options.
var title;
var subtitle;
var edit = 0;
var nav = 0;
var min_items = 0;
var max_items = 0;

var http_buffer = "";
var http_status = 0;
var timerid;

//Button texts.
var BTN_BACK_TEXT     = top.error_msg[3];
var BTN_REFRESH_TEXT1 = top.error_msg[4];
var BTN_REFRESH_TEXT2 = top.error_msg[5];
var BTN_EDIT_TEXT1    = top.error_msg[6];
var BTN_EDIT_TEXT2    = top.error_msg[7];

//
// init() - Initialization.
//
window.onload  = function()
{
 init();
};
function init()
{
  if(checkBrowserMode() == 0) {

    if (alert_msg) {
      alert(alert_msg);  
    }
    
    title = null;
    subtitle = null;
    edit = 0;
    nav = 0;
    min_items = 0;
    max_items = 0;
    loadPage(3);
    timerid = setTimeout("refreshPage()", 1000);
  } else {
    document.write('<h2>This browser is not supported!</h2> (' + err + ')');  
  }
}

//
// refreshPage() - Refreshes the content of the page.
//
function refreshPage()
{
  timerid = setTimeout("refreshPage()", 1000);  //Reset the timer.

  if (refresh == 1) {
    if (http_status == 0) {
      loadPage(1);
    }
  }
}

//
// loadPage(p)
//
//  p:
//  1 - download page and load page contents
//  2 - download page and load configuration
//  3 - download page and load configuration and page contents
//
function loadPage(p)
{
  if (top.viewmode == 0) {
    makeHttpRequest("/hvi?file=" + datapage + "&pos1=" + pos1 + "&pos2=" + pos2, "bufferPage", p);
  } else {
    makeHttpRequest("/hvi?file=" + datapage, "bufferPage", p);
  }
}

//
// bufferPage(p, page)
//
//  p:
//   1 - load page contents
//   2 - load configuration
//   3 - load configuration and page contents
//
//  page:
//   complete html page
//
function bufferPage(p, page)
{
  http_buffer = translate(page);

  if (p == 1) {
    printData();    
  } else if(p == 2) {
    getConfig();      
  } else {
    if(getConfig() == 1) {
      loadPage(3);   
    } else {
      printData();  
    }
  }
}

//
// makeHttpRequest()
//
function makeHttpRequest(url, callback_function, callback_parameters, return_xml)
{
  var http_request = false;

  if (window.XMLHttpRequest) { // Mozilla, Safari,...
    http_request = new XMLHttpRequest();
    if (http_request.overrideMimeType) {
      http_request.overrideMimeType('text/xml');
    }
  } else if (window.ActiveXObject) { // IE
    try {
      http_request = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
      try {
        http_request = new ActiveXObject("Microsoft.XMLHTTP");
      } catch (e) {}
    }
  }

  if (!http_request) {
    eval(callback_function + '("Unfortunately you browser doesn\'t support this feature.")');
    return false;
  }

  http_request.onreadystatechange = function() {
    if (http_request.readyState == 4) {
      http_status = 0;
      if (http_request.status == 200) {
        if (return_xml) {
          eval(callback_function + '(' + callback_parameters + ', http_request.responseXML)');
        } else {
          eval(callback_function + '(' + callback_parameters + ',http_request.responseText)');
        }
      } else {
        eval(callback_function + '("' + translate(top.error_msg[0]) + '")');
//        alert('There was a problem with the request.(Code: ' + http_request.status + ')');
//        eval(callback_function + '("Er is een probleem met het ophalen van de informatie.")');
      }
    }
  }
  
  http_request.open('GET', url, true);
  http_request.send(null);
  this.loadPageIndicator(1);
  http_status = 1;
}

//
// getConfig() - Get the configuration from HTML file.
//
function getConfig()
{
  title = null;
  subtitle = null;
  max_items = 0;
  min_items = 0;
  nav = 0;
  edit = 0;

  //Get the data from the global buffer.
  var data_array = http_buffer.split('\n');

  //Update load indicator (green square).
  loadPageIndicator(0);

  if (top.viewmode == 0) { 
    //View mode = tft.
    buttons = 1; 
  } else {
    //View mode = pc.
    buttons = top.buttons;
    refresh = top.refresh;
  }

  for (var line_index in data_array) {
    var item_array = data_array[line_index].split(';');
    
    switch(item_array[0]) {
      case ':TITLE':            // Title
        title = item_array[1];
        break;
      case ':SUBTITLE':         // Subtitle
        subtitle = item_array[1];
        break;
      case ':MAX':              // Maximum items
        max_items = parseInt(item_array[1]);
        break;
      case ':MIN':              // Minimum items
        min_items = parseInt(item_array[1]);
        break;
      case ':NAVBAR':
        if (top.viewmode == 0) { //tft
          nav = parseInt(item_array[1]);
        }
        break;
      case ':EDIT':
        if (top.viewmode == 0) { //tft
          edit = parseInt(item_array[1]);
        }
        break;
      case ':REFRESH':            // Global refresh
        if (top.viewmode == 0) { //tft
          refresh = parseInt(item_array[1]);
        }
        break;
      case ':PCREFRESH':          // PC hardcoded refresh
        if (top.viewmode == 1) { //pc
          refresh = parseInt(item_array[1]);
        }
        break;
      case ':PAGESIZE':           // Pagesize
        pagesize = parseInt(item_array[1]);
      }
  }

  var oldpos1 = pos1;
  var oldpos2 = pos2;

  loadPagePosition();

  printNav();

  switch(nav) {
    case 0:
      pos1 = min_items;
      pos2 = max_items;
      break;
    case 1:
      pos1 = min_items;
      pos2 = max_items;
      break;
    case 2:
      pos1 = min_items;
      pos2 = max_items;
      break;
    case 3:
      countPages();
      navText();
      break;  
    default:
      pos1 = min_items;
      pos2 = max_items;
      break;  
  }
  
  // If the row positions are not in sync load the page again.
  if((oldpos1 != pos1)||(oldpos2 != pos2)) {
    return 1;  
  }
  
  return 0;
}

//
// printData()
//
function printData() 
{ 
  var data_div = document.getElementById('data'); 
  
  var textarea_div = document.getElementById('textarea');

  var time1 = new Date().getTime();

  var e_row = new Array();   // column edit info
  var f_row = new Array();   // column format info
  var p_row = new Array();   // column parameter info
  var h_row = new Array();   // column header info
  var w_row = new Array();   // column width info
  var c_row = new Array();   // cell colors info
  var s_row = new Array();   // spanning columns info
  var r_row = new Array();   // spanning columns info
  var dotable = 0;
  var dotextarea = 0; 
  var firstline = 0;
  var edit_naam;
  var edit_index;
  var row_index = -1;
  var t = new Array();       // table in html
  var h = new Array();       // table header in html
  var d = new Array();       // table data in html
  var data = new Array();    // all data in html

  loadPageIndicator(0);

  var data_array = http_buffer.split('\n');

  for (var line_index in data_array) {
    if (data_array[line_index].substr(0,1) != ':') {
      // HTML-line
      if(data_array[line_index].length > 0)
      if(dotextarea){
        if(firstline)
        {
            firstline = 0;
            textarea_div.innerHTML += data_array[line_index];
        }
        else
        {
            textarea_div.innerHTML += "<br/>" + data_array[line_index];
        }
        textarea_div.scrollTop = textarea_div.scrollHeight
      }
      else if (!dotable) { data.push(data_array[line_index]); }
    } else {
      //Data-line
      var item_array = data_array[line_index].split(';');
      /* Begin normal table */
      if (item_array[0] == ':BEGINTABLE') {
        t = null;
        d = null;
        h = null;
        e_row = null;
        f_row = null;
        p_row = null;
        h_row = null;
        w_row = null;
        c_row = null;
        r_row = null;
        s_row = null;
        t = new Array();
        h = new Array();
        d = new Array();
        e_row = new Array();
        f_row = new Array();
        p_row = new Array();
        h_row = new Array();
        w_row = new Array();
        c_row = new Array();
        r_row = new Array();
        s_row = new Array();
        t.push('<TABLE>');
        h.push('<THEAD>');
        d.push('<TBODY>');
        dotable = 1;
      }

      // Begin main table
      if (item_array[0] == ':BEGINMAINTABLE') {
        t = null;
        d = null;
        h = null;
        e_row = null;
        f_row = null;
        p_row = null;
        h_row = null;
        w_row = null;
        c_row = null;
        r_row = null;
        s_row = null;
        t = new Array();
        h = new Array();
        d = new Array();
        e_row = new Array();
        f_row = new Array();
        p_row = new Array();
        h_row = new Array();
        w_row = new Array();
        c_row = new Array();
        r_row = new Array();
        s_row = new Array();
        t.push('<TABLE>');
        h.push('<THEAD>');
        d.push('<TBODY>');
        dotable = 2;
        row_index = 0;
      }
     if (item_array[0] == ':BEGINTEXTAREA') {
        dotextarea  = 1;
        firstline   = 1; 
      }
     if (item_array[0] == ':ENDTEXTAREA') {
        dotextarea  = 0;
      }
      /* End table */
      if ((item_array[0] == ':ENDTABLE') || (item_array[0] == ':ENDMAINTABLE')) {
        /* Add tableheader to table  */
        h.push('</THEAD>');
        if (h.join('') != '<THEAD></THEAD>') {
          t.push(h.join(''));
        }
        /* Add tablebody to table */
        d.push('</TBODY>');
        if (d.join('') != '<TBODY></TBODY>') {
          t.push(d.join(''));
        }
        /* Add Table */
        t.push('</TABLE><BR>');
        if (t.join('') != '<TABLE></TABLE><BR>') {
          data.push(t.join(''));
        }
        dotable = 0;
      }
      /* Column options */
      if ((item_array[0] == ':E') && (dotable)) {
        for (var item_index in item_array) {
          if (item_index > 0) {
            e_row[item_index] = item_array[item_index];
            if (item_array[item_index - 1] == 'N') {
              edit_naam = item_index - 1;
            }
            if (item_array[item_index - 1] == 'I') {
              edit_index = item_index - 1;
            }
          }
        }
      }
      
      /* Formats */
      if ((item_array[0] == ':F') && (dotable)) {
        for (var item_index in item_array) {
          if (item_index > 0) {
            f_row[item_index] = item_array[item_index];
          }
        }
      }
      /* Parameters */
      if ((item_array[0] == ':P') && (dotable)) {
        while(p_row.pop()) {}
        for (var item_index in item_array) {
          if (item_index > 0) {
            p_row[item_index] = item_array[item_index];
          }
        }
      }
      /* Column width */
      if ((item_array[0] == ':W') && (dotable)) {
        while(w_row.pop()) {}
        for (var item_index in item_array) {
          if (item_index > 0) {
            w_row[item_index] = item_array[item_index];
          }
        }
      }
      /* cell colours */
      if ((item_array[0] == ':C') && (dotable)) {
        while(c_row.pop()) {}
        for (var item_index in item_array) {
          if (item_index > 0) {
            c_row[item_index] = item_array[item_index];
          }
        }
      }
      if ((item_array[0] == ':R') && (dotable)) {
        while(r_row.pop()) {}
        for (var item_index in item_array) {
          if (item_index > 0) {
            r_row[item_index] = item_array[item_index];
          }
        }
      }      
      /* cell spanning multiple columns */
      if ((item_array[0] == ':S') && (dotable)) {
        while(s_row.pop()) {}
        for (var item_index in item_array) {
          if (item_index > 0) {
            s_row[item_index] = item_array[item_index];
          }
        }
      }
      /* Table header */
      if ((item_array[0] == ':H') && (dotable)) {
        h.push('<TR>');
        for (var item_index in item_array) {
          h_row[item_index] = item_array[item_index];
          if (item_index > 1) {
            h.push('<TD>' + item_array[item_index] + '</TD>');
          }
        }
        h.push('</TR>');
      }
      /* Table data */
      if ((item_array[0] == ':D') && (dotable)) {
        if ((nav == 3) && (editpos == row_index) && (refresh == 0) && (edit == 1)) {
          d.push('<TR class="edit">');
        } else {
          d.push('<TR>');
        }
        for (var item_index in item_array) {
          if (item_index > 1) {
            /* Create column width item */
            width = (w_row[item_index] ? ' width="' + w_row[item_index] + '"' : '');
            /* add cell color */
            bg_color = (c_row[item_index] ? ' style="background-color:' + c_row[item_index] + '"' : '');
            col_span = (s_row[item_index] ? ' colspan="' + s_row[item_index] + '"' : '');
            row_span = (r_row[item_index] ? ' rowspan="' + r_row[item_index] + '"' : '');
            col_fmt = (width + bg_color + col_span + row_span);

            if (nav < 3) {
              /* hole page view */
              if ((e_row[item_index] == 'U') && (refresh == 0)) {
                /* als deze kolom editable is en er mag gewijzigd worden */
                if (f_row[item_index] == 'UF') {
                  if (buttons) {
                    d.push('<TD' + col_fmt + ' class="edit"><BUTTON type="button" onclick=\'doUserFunction("' + p_row[item_index] + '","' + item_array[edit_index] + '")\'>' + item_array[item_index] + '</BUTTON></TD>');
                  } else {
                    d.push('<TD' + col_fmt + ' class="edit" ondblclick=\'doUserFunction("' + p_row[item_index] + '","' + item_array[edit_index] + '")\'>' + item_array[item_index] + '</TD>');
                  }
                } else {
                  if (buttons) {
                    d.push('<TD' + col_fmt + ' class="edit"><BUTTON type="button" onclick=\'doEdit("' + (h_row[item_index] ? h_row[item_index]: '') + ' ' + item_array[edit_naam] + ' = ' + item_array[item_index] + '","' + p_row[item_index] + '/' + item_array[edit_index] + '","' + f_row[item_index] + '")\'>' + item_array[item_index] + '</BUTTON></TD>');
                  } else {
                    d.push('<TD' + col_fmt + ' class="edit" ondblclick=\'doEdit("' + (h_row[item_index] ? h_row[item_index]: '') + ' ' + item_array[edit_naam] + ' = ' + item_array[item_index] + '","' + p_row[item_index] + '/' + item_array[edit_index] + '","' + f_row[item_index] + '")\'>' + item_array[item_index] + '</TD>');
                  }
                }
              } else {
                /* data gewoon laten zien */
                d.push('<TD' + col_fmt + '>' + item_array[item_index] + '</TD>');
              }
            } else {
              /* page view */
              if ((editpos == row_index) || (dotable == 1)) {
                /* rij mag gewijzigd worden */
                if ((e_row[item_index] == 'U') && (refresh == 0)) {
                  /* kolom mag gewijzigd worden */
                  if (f_row[item_index] == 'UF') {
                    if (buttons) {
                      d.push('<TD' + col_fmt + ' class="edit"><BUTTON type="button" onclick=\'doUserFunction("' + p_row[item_index]+ '","' + item_array[edit_index] + '")\'>' + item_array[item_index] + '</BUTTON></TD>');
                    } else {
                      d.push('<TD' + col_fmt + ' class="edit" ondblclick=\'doUserFunction("' + p_row[item_index] + '","' + item_array[edit_index] + '")\'>' + item_array[item_index] + '</TD>');
                    }
                  } else {
                    if (buttons) {
                      d.push('<TD' + col_fmt + ' class="edit"><BUTTON type="button" onclick=\'doEdit("' + (h_row[item_index] ? h_row[item_index]: '') + ' ' + item_array[edit_naam] + ' = ' + item_array[item_index] + '","' + p_row[item_index] + '/' + item_array[edit_index] + '","' + f_row[item_index] + '")\'>' + item_array[item_index] + '</BUTTON></TD>');
                    } else {
                      d.push('<TD' + col_fmt + ' class="edit" ondblclick=\'doEdit("' + (h_row[item_index] ? h_row[item_index]: '') + ' ' + item_array[edit_naam] + ' = ' + item_array[item_index] + '","' + p_row[item_index] + '/' + item_array[edit_index] + '","' + f_row[item_index] + '")\'>' + item_array[item_index] + '</TD>');
                    }
                  }
                } else {
                  /* kolom mag niet gewijzigd worden; data laten zien */
                  d.push('<TD' + col_fmt + '>' + item_array[item_index] + '</TD>');
                }
              } else {
                /* rij mag niet gewijzigd worden; data laten zien */
                d.push('<TD' + col_fmt + '>' + item_array[item_index] + '</TD>');
              }
            }
          }
        }
        d.push('</TR>');
        if (dotable == 2) {
          row_index++;
        }
      }
    }
  }

  //Push tables and html into the div.
  data_div.innerHTML = data.join('');

  if (title) {
    var title_div = document.getElementById('title');
    title_div.innerHTML = title;
  }

  if (subtitle) {
    var title2_div = document.getElementById('title2');
    title2_div.innerHTML = subtitle;
  }

  // Create Help Link
  var help_div = document.getElementById('help');
  if (typeof help === 'undefined') {
    help_div.innerHTML = '<i>Help</i>';
  }
  else {
    help_div.innerHTML = '<a class="helplink" onClick="showHelp(\''+help+'\')" href="#"  title=\' Help \'>Help</a>';
  }

  var time2 = new Date().getTime();
//  printOptions(time1, time2);
}

//
// printHTML()
//
function printHTML(data_string) 
{ 
  var data_div = document.getElementById('data'); 
  var s = new Array();
  var data_array = data_string.split('\n');

  for (var line_index in data_array) {
    if (data_array[line_index].substr(0,1) != ':') {
      s.push(data_array[line_index]);      
    }
  }
  
  data_div.innerHTML = s.join('');
}

//
// printOptions(time1, time2)
//
function printOptions(time1, time2)
{
  if ((time1) && (time2)) {
    tijd = time2 - time1;
  }
  var tijd_div = document.getElementById('tijd');

  back = getCookie("back");
  back = (back == null) ? "" : back;
  
  tijd_div.innerHTML = 'Process time: '  + tijd      + 'ms<br />' +
                       'Minimum items: ' + min_items + '<br />' +
                       'Maximum items: ' + max_items + '<br />' +
                       'Refresh: '       + refresh   + '<br />' +
                       'Page: '          + page      + '<br />' +
                       'Pos1: '          + pos1      + '<br />' +
                       'Pos2: '          + pos2      + '<br />' +
                       'Nav: '           + nav       + '<br />' +
                       'Edit: '          + edit      + '<br />' +
                       'Editpos: '       + editpos   + '<br />';
}

//
// doEdit(label, parname, format)
//
function doEdit(label, parname, format) 
{
  document.settingstable.edit_caption.value = translate(title);
  document.settingstable.edit_label.value = translate(label);
  document.settingstable.edit_par.value = parname;
  document.settingstable.edit_format.value = format;

  switch( format )
  { 
    case "SYNCMODE":
      document.settingstable.edit_file.value = "edit_syncmode_form.hvi";
      break;
    case "CLFDAY":
      document.settingstable.edit_file.value = "edit_day_form.hvi";
      break;
    case "TBUCHF":
      document.settingstable.edit_file.value = "edit_hlog_form.hvi";
    break;
    case "R30":
      document.settingstable.edit_file.value = "edit_r30_form.hvi";
      break;
    case "XDETERC":
      document.settingstable.edit_file.value = "edit_failstate_form.hvi";
      break;
    case "ABLE":
      document.settingstable.edit_file.value = "edit_able_form.hvi";
      break;
    case "MTCFUK":
      document.settingstable.edit_file.value = "edit_mtcf_form.hvi";
      break;
    case "R1":
    case "R2":
    case "P":
      document.settingstable.edit_file.value = "edit_r1_form.hvi";
      break;
    case "HRS":
      document.settingstable.edit_file.value = "edit_r1_form.hvi";
      break;
	  
	case "HEX":
	   document.settingstable.edit_file.value = "edit_hex_form.hvi";
	   break;
    case "CLFFUNC":
      document.settingstable.edit_file.value = "edit_clfinfl_form.hvi";
      break;
    case "MINS":
      document.settingstable.edit_file.value = "edit_r1_form.hvi";
      break;
    case "MPH":
      document.settingstable.edit_file.value = "edit_r1_form.hvi";
      break;
    case "DATE":
      document.settingstable.edit_file.value = "edit_r1_form.hvi";
      break;
    case "R20":
      document.settingstable.edit_file.value = "edit_r20_form.hvi";
      break;
    case "R21":
      document.settingstable.edit_file.value = "edit_r21_form.hvi";
      break;
    case "TPGM":
      document.settingstable.edit_file.value = "edit_tpgm_form.hvi";
      break;
    case "TPGF":
      document.settingstable.edit_file.value = "edit_tpgf_form.hvi";
      break;
    case "DET":
      document.settingstable.edit_file.value = "edit_det_form.hvi";
      break;
    case "RIO":
      document.settingstable.edit_file.value = "edit_rio_form.hvi";
      break;
    case "SG":
      document.settingstable.edit_file.value = "edit_sg_form.hvi";
      break;
    case "MDAY":
      document.settingstable.edit_file.value = "edit_mday_form.hvi";
      break;
    case "MODE":
      document.settingstable.edit_file.value = "edit_mode_form.hvi";
      break;
    case "BAUD":
      document.settingstable.edit_file.value = "edit_baud_form.hvi";
      break;
    case "MTCF":
      document.settingstable.edit_file.value = "edit_mtcf_form.hvi";
      break;
    case "PHDTYPE":
      document.settingstable.edit_file.value = "edit_phdtype_form.hvi";
      break;
    case "FT":
      document.settingstable.edit_file.value = "edit_r1_form.hvi";
      break;
    case "RECAL":
      document.settingstable.edit_file.value = "edit_recal_form.hvi";
      break;
    case "OTUINV":
      document.settingstable.edit_file.value = "edit_otuinv_form.hvi";
      break;
    case "SCOOTYN":
      document.settingstable.edit_file.value = "edit_scootyn_form.hvi";
      break;
    case "CONFIRM":
      document.settingstable.edit_file.value = "edit_confirm_form.hvi";
      break;
    case "MIMIC":
      document.settingstable.edit_file.value = "edit_mimic_form.hvi";
      break;
    case "PH":
      document.settingstable.edit_file.value = "edit_ph_form.hvi";
      break;
    case "LERROR":
      document.settingstable.edit_file.value = "edit_lerror_form.hvi";
      break;
    case "EMPTY":
      document.settingstable.edit_file.value = "edit_empty_form.hvi";
      break;
    case "SON":
      document.settingstable.edit_file.value = "edit_son_form.hvi";
      break;
    case "UG405OPMF":
      document.settingstable.edit_file.value = "edit_UG405_operational_form.hvi";
      break;
    case "LRT":
      document.settingstable.edit_file.value = "edit_LRT_form.hvi";
      break;
    case "YMDRAWUK":
	case "YMDRAW":
      document.settingstable.edit_file.value = "edit_ymdraw_form.hvi";
      break;
    case "CLFRT":
      document.settingstable.edit_file.value = "edit_clfrt_form.hvi";
      break;
    case "CLFSYNC":
      document.settingstable.edit_file.value = "edit_clfsync_form.hvi";
      break;
    case "WDAY":
      document.settingstable.edit_file.value = "edit_wday_form.hvi";
      break;
    default:
      document.settingstable.edit_file.value = "edit_r1_form.hvi";
      break;
  }
    
  savePagePosition();
  document.settingstable.submit();    
}

//
// doDbWrite(parname, val)
//
function doDbWrite(parname, val)
{
  document.settingstable.edit_caption.value = translate(title);
  document.settingstable.edit_label.value = val;
  document.settingstable.edit_par.value = parname;
  document.settingstable.edit_file.value = "db_write_form.hvi";
  savePagePosition();
  document.settingstable.submit();
}

//
// doUserFunction(uf, val)
//
function doUserFunction(uf,val) 
{
/*  edit_div = document.getElementById('edit'); 
  
  edit_div.innerHTML = 'User Function: ' + uf      + '<br />' + 
                       'Datapage:' + datapage;*/
  
  savePagePosition();
  if (val) {
    top.doUFHref(datapage,uf,val);
  } else {
    top.doUFHref(datapage,uf);
  }
}

/********************************************************************************************/
/* NAVIGATION FUNCTIONS                                                                     */
/********************************************************************************************/

//
// printNav()
//
function printNav()
{
  var s = new Array();
  var s2 = new Array();

  switch(nav) {
    case 0: 
      s.push('');
      break;
    case 1:
      s.push('<form name="NavForm">');
      s.push('<table cellpadding="0" cellspacing="0" border="0" width="100%">');
      s.push('<tr><td align="left">');
      s.push('<button type="button" class="big" OnClick="top.doBack()">' + translate(BTN_BACK_TEXT) + '</button>');
      s.push('</td></tr>');
      s.push('</table>');
      s.push('</form>');
      break;
    case 2:
      s.push('<form name="NavForm">');
      s.push('<table cellpadding="0" cellspacing="0" border="0" width="100%">');
      s.push('<tr><td align="left">');
      s.push('<button type="button" class="big" OnClick="top.doBack()">' + translate(BTN_BACK_TEXT) + '</button>');
      s.push('</td><td align="right">');
      if (!edit) {
        if (refresh == 0) {
          s.push('<button type="button" class="big" id="refresh_button" OnClick="doNavRefresh()">' + translate(BTN_REFRESH_TEXT1) + '</button>');
        } else {
          s.push('<button type="button" class="big" id="refresh_button" OnClick="doNavRefresh()">' + translate(BTN_REFRESH_TEXT2) + '</button>');
        }
      } else {
        if (refresh == 0) {
          s.push('<button type="button" class="big" id="refresh_button" OnClick="doNavRefresh()">' + translate(BTN_EDIT_TEXT1) + '</button>');
        } else {
          s.push('<button type="button" class="big" id="refresh_button" OnClick="doNavRefresh()">' + translate(BTN_EDIT_TEXT2) + '</button>');
        }
      }
      s.push('</td></tr>');
      s.push('</table>');
      s.push('</form>');
      break;
    case 3: //controls: back, <|, <, >, >|, freeze
      s.push('<form name="NavForm">');
      s.push('<table cellpadding="0" cellspacing="0" border="0" width="100%">');
      s.push('<tr><td align="left">');
      s.push('<button type="button" class="big" OnClick="top.doBack()">' + translate(BTN_BACK_TEXT) + '</button>');
      s.push('</td><td align="center" width="100%">');
      s.push('<button type="button" OnClick="doNavBegin()">|&lt;</button>');
      s.push('<button type="button" OnClick="doNavPrevPage()">&lt;</button>');
      s.push('<input type="text" name="tekst">');
      s.push('<button type="button" OnClick="doNavNextPage()">&gt;</button>');
      s.push('<button type="button" OnClick="doNavEnd()">&gt;|</button>');
      s.push('</td>');
      s.push('<td align="right">');
      if (!edit) {
        if (refresh == 0) {
          s.push('<button type="button" class="big" id="refresh_button" OnClick="doNavRefresh()">' + translate(BTN_REFRESH_TEXT1) + '</button>');
        } else {
          s.push('<button type="button" class="big" id="refresh_button" OnClick="doNavRefresh()">' + translate(BTN_REFRESH_TEXT2) + '</button>');
        }
      } else {
        if (refresh == 0) {
          s.push('<button type="button" class="big" id="refresh_button" OnClick="doNavRefresh()">' + translate(BTN_EDIT_TEXT1) + '</button>');
        } else {
          s.push('<button type="button" class="big" id="refresh_button" OnClick="doNavRefresh()">' + translate(BTN_EDIT_TEXT2) + '</button>');
        }
      }
      s.push('</td></tr>');
      s.push('</table>');
      s.push('</form>');
      break;
    case 10:
      s2.push('<ul>');
      s2.push('<li><button type=button OnClick=\'top.doDataHref("cell1370.hvi",1)\'>' + translate(top.error_msg[1]) + '</button></li>');
      s2.push('<li><button type=button OnClick=\'top.doDataHref("cell1240.hvi",1)\'>' + translate(top.error_msg[2]) + '</button></li>');
      s2.push('</ul>');
      break;
    default:
      s.push('');
      break;
  }
  
  nav_div = document.getElementById('nav'); 
  
  nav_div.innerHTML = s.join('');

  nav_home_div = document.getElementById('nav_home'); 
  
  nav_home_div.innerHTML = s2.join('');
}

//
// doNavRefresh()
//
function doNavRefresh()
{
  if (!edit) {
    if (refresh == 0) {
      document.getElementById("refresh_button").innerHTML = translate(BTN_REFRESH_TEXT2);
      refresh = 1;
    } else {
      document.getElementById("refresh_button").innerHTML = translate(BTN_REFRESH_TEXT1);
      refresh = 0;
    }
  } else {
    if (refresh == 0) {
      document.getElementById("refresh_button").innerHTML = translate(BTN_EDIT_TEXT2);
      refresh = 1;
    } else {
      document.getElementById("refresh_button").innerHTML = translate(BTN_EDIT_TEXT1);
      refresh = 0;
    }
  }
  
  loadPage(1);
}

//
// doNavBegin()
//
function doNavBegin() 
{
  if ((refresh == 0) && (edit)) {
    editpos = 0;
  } else {
    page = 0;
  }
  navText();
  if(refresh == 0) { 
    if (edit == 1) {
      printData();
    } else {
      loadPage(1);
    }
  }
}

//
// doNavEnd()
//
function doNavEnd() 
{
  if ((refresh == 0) && (edit)) {
    if (page == (maxpage-1)) {
      editpos = lastpagesize - 1;
    } else {
      editpos = pagesize - 1;
    }
  } else {
    page = maxpage - 1;
    if (editpos >= lastpagesize) {
      editpos = lastpagesize - 1;
    }
  }
  navText();
  if(refresh == 0) { 
    if (edit == 1) {
      printData();
    } else {
      loadPage(1);
    }
  }
}

//
// doNavNextPage()
// 
function doNavNextPage() 
{
  var load;

  if(edit == 1) { 
    load = 1;
  }
  
  if((refresh == 0) && (edit)) 
  {
    if (page == (maxpage-1)) 
    {
      if (editpos < (lastpagesize-1)) 
      {
        editpos++;
      }
    } 
    else 
    {  
      if (editpos < (pagesize-1)) 
      {
        editpos++;
      } 
      else 
      {
        editpos = 0;
        page++;
        load = 0;
      }
    }
  } else {
    if (page < (maxpage-1)) {
      page++;
      if ((page == (maxpage-1)) && (editpos > lastpagesize)) {
        editpos = lastpagesize;
      }
    }
  }
  navText();
  if (refresh == 0) {
    if (load == 1) {
      printData();
    } else {
      loadPage(1);  
    }
  }
}

//
// doNavPrevPage()
//
function doNavPrevPage() 
{
  var load;

  if(edit == 1) { 
    load = 1;
  }
  
  if ((refresh == 0) && (edit)) {
    if (page == 0) {
      if (editpos > 0) {
        editpos--;
      }
    } else {
      if (editpos > 0) {
        editpos--;
      } else {
        editpos = pagesize - 1;
        page--;
        load = 0;
      }
    }
  } else {
    if (page > 0) {
      page--;
    }
  }
  navText();
  if (refresh == 0) {
    if (load == 1) {
      printData();
    } else {
      loadPage(1);  
    }
  }
}

//
// navText()
//
function navText()
{
  makePos();
  var temp1 = pos1 + editpos + 1;
  var temp2 = max_items;
  document.NavForm.tekst.value = "" + temp1 + "/" + temp2;
}

//
// makePos()
//
function makePos()
{
  pos1 = (page * pagesize) + min_items;
  pos2 = pos1 + pagesize - 1;
}

//
// countPages()
//
function countPages()
{
  maxpage = parseInt((max_items - min_items) / pagesize);
  lastpagesize = parseInt((max_items - min_items) % pagesize);
  if(lastpagesize == 0) 
  {
    if(maxpage) 
    {
      lastpagesize = pagesize;
    }
    else
    {
      /* No data */
      lastpagesize = 0;
      maxpage = 1; 
    }
  }
  else
  {
    maxpage++; 
  }
}

//
// savePagePosition()
//
function savePagePosition()
{
  top.dp_datapage = datapage;
  top.dp_page     = page;
  top.dp_editpos  = editpos;
  top.dp_refresh  = refresh;
  top.dp_scroll_line = (document.all) ? document.documentElement.scrollTop : window.pageYOffset;
}

//
// loadPagePosition()
//
function loadPagePosition() 
{
  if(top.dp_datapage == datapage) {
    page    = top.dp_page;
    editpos = top.dp_editpos;
    refresh = top.dp_refresh;
  } else {
    clearPagePosition();  
  }
}

//
// clearPagePosition()
//
function clearPagePosition()
{
  top.dp_datapage = "";
  top.dp_page     = null;
  top.dp_editpos  = null;
  top.dp_refresh  = null;
  top.dp_scroll_line = null;
}

//
// loadScrollPosition() - Load the old scrollposition.
//
function loadScrollPosition() 
{
  if(top.dp_datapage == datapage) {
    window.scrollBy(0, top.dp_scroll_line); 
  }
}

//
// loadPageIndicator(s) - Update the page load indicator.
//
//  s:
//   0 - off
//   1 - on
//
function loadPageIndicator(s)
{
  var load_div;
  
  // check if inst_frame exists
  if (top.frames['inst_frame']) {
    load_div = top.inst_frame.document.getElementById('loadind'); 
  }
  
  if (load_div) {
    if (s) {
      load_div.style.backgroundColor = '#00c700';  //green
    } else {
      load_div.style.backgroundColor = '#DDDDDD';  //grey
    }    
  } 
}

//
// checkBrowserMode()
//
function checkBrowserMode()
{
  err = 0;
  
  // check if browser can handle W3C DOM
  if (!document.getElementById) {
    err = 1;
  }
  
  //Check if browser supports javascript http requests
  if ((!window.XMLHttpRequest)&&(!window.ActiveXObject)) {
    err = 2;
  }

  //Check if this page is loaded in index.html
  if (parent == self) {
    top.location.href = "index.html";
  }

  //check for history
  if (!top.historyArray[0]) {
    /* Jump to first page */
    top.doDataHref('m001.hvi',0);  
  }
  
  return err;
}

//
// Open help in popup window
//
function showHelp(helplink)
{
	var dpg_array = datapage.split('.');
	helpwindow_id = window.open( dpg_array[0]+ ".html" , "helpwindow", "status = 1, height = 600, width = 600, resizable = 1, scrollbars = 1" )
	this.window.focus();
	setTimeout("isHelpAvl();",500);
}

//
// Check if help file available or not, this function is called by setTimeout
//
function isHelpAvl()
{
	try{
		if(helpwindow_id.document.title && helpwindow_id.document.title != "Error!"){
				helpwindow_id.focus();
		}
		else{
			helpwindow_id.close();
			alert ("No help available for this section");
		}	
	}
	catch(ex){
		helpwindow_id.close();
		alert ("No help available for this section");
	}
}


function GetRamScript()
{	
// document.getElementById("demo").innerHTML = "";	

// document.getElementById("a1").innerHTML = "";	
	
const element = document.getElementsByTagName("table")[1];

const words1 = element.innerHTML.split(' ');

var words = words1.length //count words

var RAM_Enteries = 0

if (words>(0)) {
	document.getElementById("demo").innerHTML = "";
  RAM_Enteries = ((words-1)/7)
 // console.log(RAM_Enteries);

	}
	else {
			document.getElementById("demo").innerHTML = "";
		RAM_Enteries = 0
		}
		
if (RAM_Enteries>0) {
 // 		document.getElementById("demo").innerHTML = (words[5]);	
 
		  var node = document.createElement("div");
  var textnode = document.createTextNode("CONNECT\n");
  node.appendChild(textnode);
  document.getElementById("demo").appendChild(node);	
  
  		  var node = document.createElement("div");
  var textnode = document.createTextNode("Break\n");
  node.appendChild(textnode);
  document.getElementById("demo").appendChild(node);
  
    		  var node = document.createElement("div");
  var textnode = document.createTextNode("@lo 3145\n");
  node.appendChild(textnode);
  document.getElementById("demo").appendChild(node);
  
  N=1
		
for (let i = 0; i < RAM_Enteries; i++) {
	

	  	var RAMdata = element.getElementsByTagName("td")[N].innerHTML.split(' ');
		  var node = document.createElement("div");
  var textnode = document.createTextNode("@wr " + RAMdata[4] + " " + RAMdata[5] + "\n");
  node.appendChild(textnode);
  document.getElementById("demo").appendChild(node);
 
  N += 2
}

		  var node = document.createElement("div");
  var textnode = document.createTextNode("exit");
  node.appendChild(textnode);
  document.getElementById("demo").appendChild(node);

document.getElementById("a1").innerHTML = "Download RAM Scipt";	

const a1 = document.getElementById("a1");
const blob1 = new Blob([convertToPlain(document.getElementById("demo").innerHTML).replace(/\n/g, "\r\n")], {type: "text/plain"})
a1.href = URL.createObjectURL(blob1);

document.getElementById("demo").innerHTML = "";	

}	
else {
	document.getElementById("demo").innerHTML = "No data to create script";	
	}

function convertToPlain(html){

    // Create a new div element
    var tempDivElement = document.createElement("div");

    // Set the HTML content with the given value
    tempDivElement.innerHTML = html;

    // Retrieve the text property of the element 
    return tempDivElement.textContent || tempDivElement.innerText || "";
}

}


function ConvertRamToText()
{	


var table = document.getElementById("myTable");
var table1 = table.getElementsByTagName("tr").length;


for (let i = 0; table1>1; i++) {
	  document.getElementById("myTable").deleteRow(1);
	
	var table1 = table.getElementsByTagName("tr").length;
} 

// console.log(table1);


const element = document.getElementsByTagName("table")[1];
const words1 = element.innerHTML.split(/[\s/.]+/);
var words = words1.length //count words
const words2 = element.innerHTML.split(' ');
var words3 = words2.length //count words

// console.log(words);

var RAM_Enteries = 0

//console.log(RAM_Enteries);
//console.log(words3);


if (words3>(2)) {
	document.getElementById("demo1").innerHTML = "";
	document.getElementById("demo2").innerHTML = "";
	document.getElementById("a2").innerHTML = "";	
  RAM_Enteries = ((words3-1)/7)

	}
	else {
	document.getElementById("demo1").innerHTML = "";
	document.getElementById("demo2").innerHTML = "";
	document.getElementById("a2").innerHTML = "";
		RAM_Enteries = 0
		}
		
		//console.log(RAM_Enteries);
		
if (RAM_Enteries>0) {

   N=1
		
	//	console.log(RAM_Enteries);



			  var x = document.getElementById("myTable");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
  
   var y = document.getElementById("Download_RAM_Text");
  if (y.style.display === "block") {
    y.style.display = "none";
  } else {
    y.style.display = "block";
  }

for (let i = 0; i < RAM_Enteries; i++) {
	

	  	var RAMdata = element.getElementsByTagName("td")[N].innerHTML.split(/[\s/.]+/);
		var text1 = element.getElementsByTagName("td")[N].innerHTML.split(/[\s/.]+/);
		var currentVal=text1[9]
		var OriginalVal=text1[10]
		var DivideNo=text1[7]
		
		function DivideLookup(val) {
  var result = "";

  var lookup = {
      "R1": 1,
      "R2": 10,
      "R20": "R20",
	  "R21": "R21",
  	  "R11": "R11",
	  "R10": "R10",
	  undefined: 0,
  };
  return lookup[val];
}
		
		
	//	console.log(text1);
		
		  var lookup=""
		  
		function newLookup(val) {
  var result = "";

  var lookup = {
      "TG": "Minimum Green",
      "TING": "Intergreen",
	  "TM1X1": "Maximum Green in Timing Set 1",
	  "TM1X2": "Maximum Green in Timing Set 2",
	  "TM1X3": "Maximum Green in Timing Set 3",
	  "TM1X4": "Maximum Green in Timing Set 4",
	  "TM1X5": "Maximum Green in Timing Set 5",
	  "TM1X6": "Maximum Green in Timing Set 6",
	  "TM1X7": "Maximum Green in Timing Set 7",
	  "TM1X8": "Maximum Green in Timing Set 8",
  	  "TM1X9": "Maximum Green in Timing Set 9",
	  "TM1X10": "Maximum Green in Timing Set 10",
	  "TM1X11": "Maximum Green in Timing Set 11",
	  "TM1X12": "Maximum Green in Timing Set 12",
	  "TM1X13": "Maximum Green in Timing Set 13",
	  "TM1X14": "Maximum Green in Timing Set 14",
	  "TM1X15": "Maximum Green in Timing Set 15",
	  "TM1X16": "Maximum Green in Timing Set 16",
	  "PCMMAP": "Period 5",
 	  "PCAMAP": "Period 6",
	  "TLAR": "Period 7",
	  "TSAR": "Period 8",
	  "TPDF": "Pelican Period E",
	  "TPVF": "Pelican Period F",
	  "TVFL": "Pelican Period G",
	  "PHDPH": "Phase Delay (Element 0 is INDEX/ACTION:1 etc..) (Phase - e.g. A=0, B=1 etc)",
	  "PHDFSTG": "Phase Delay From Stage",
	  "PHDTSTG": "Phase Delay To Stage",
	  "PHDTIME": "Phase Delay Time (Element 0 is INDEX/ACTION:1 etc..)",
	  "XDET": "Detector Overide - where 1=Off, 2=On",
	  "DTG1": "Detector Extension time",
	  "DTO": "Detector Call Delay time",
	  "DTC": "Detector Cancel Delay time",
	  "XDETENA": "Detector DFM",
	  "XDETINV": "Detector Software Inverted",
	  "DFUNC": "Detector Function - where 1=Dem, 2=Ext, 8=Cancel (e.g. Detector to Dem & Ext would be 3)",
	  "XDETO": "DFM Active Time - in Hours & Mins (e.g. 30=30min, 100=1 hour)",
	  "XDETN": "DFM Inactive Time - in Hours & Mins (e.g. 30=30min, 1800=18 hours)",
	  "MTCF": "Timetable Function - where 1=PTC1 Control Plan, 2=Timing Set, 3=PartTime, 4=CLF Plan, 5=Isolate, 6=Audible. Beyond this - 7=User Function 1, 8=User Function 2 etc...",
	  "MTCA1": "New ARG  (Timing Set Number(Element) Argument (Current Value) (ARG1))",
	  "MTCD": "Days - where 1=Mon, 2=Tue, 4=Wed, 8=Thu, 16=Fri, 32=Sat, 64=Sun (e.g. All Week = 127)",
	  "MTCTS": "Start Time (e.g. 50= 00h:00m:50s, 500= 00h:05m:00s, 50000= 5h:00m:00s)",
	  "MTCTE": "End Time (e.g. 50= 00h:00m:50s, 500= 00h:05m:00s, 50000= 5h:00m:00s)",
	  "CLFCY": "CLF Cycle Time (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT1": "CLF Cycle Time Plan 1 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT2": "CLF Cycle Time Plan 2 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT3": "CLF Cycle Time Plan 3 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT4": "CLF Cycle Time Plan 4 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT5": "CLF Cycle Time Plan 5 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT6": "CLF Cycle Time Plan 6 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT7": "CLF Cycle Time Plan 7 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT8": "CLF Cycle Time Plan 8 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT9": "CLF Cycle Time Plan 9 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT10": "CLF Cycle Time Plan 10 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT11": "CLF Cycle Time Plan 11 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT12": "CLF Cycle Time Plan 12 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT13": "CLF Cycle Time Plan 13 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT14": "CLF Cycle Time Plan 14 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT15": "CLF Cycle Time Plan 15 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT16": "CLF Cycle Time Plan 16 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT17": "CLF Cycle Time Plan 17 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT18": "CLF Cycle Time Plan 18 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT19": "CLF Cycle Time Plan 19 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT20": "CLF Cycle Time Plan 20 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT21": "CLF Cycle Time Plan 21 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT22": "CLF Cycle Time Plan 22 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT23": "CLF Cycle Time Plan 23 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT24": "CLF Cycle Time Plan 24 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT25": "CLF Cycle Time Plan 25 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT26": "CLF Cycle Time Plan 26 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT27": "CLF Cycle Time Plan 27 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT28": "CLF Cycle Time Plan 28 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT29": "CLF Cycle Time Plan 29 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT30": "CLF Cycle Time Plan 30 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT31": "CLF Cycle Time Plan 31 (Element 0 is INDEX/ACTION:1 etc..)",
	  "CLFT32": "CLF Cycle Time Plan 32 (Element 0 is INDEX/ACTION:1 etc..)",
	  "EVP1": "The Event Pulse ON Time",
	  "EVP2": "The Event Pulse OFF Time",
	  "PARM": "The Software Switch Value",
	  "GPTM": "General Purpose Timer Value (Element 0 is INDEX/ACTION:1 etc..)",
	  "XLMU": "Lamp Monitor P1 Value",
	    };
  return lookup[val];
}

	var text13 =  text1[10].split(/[\()]+/)
	var text12 = DivideLookup(text1[7]);
	var text10 = newLookup(text1[6]);
	var text11 = ""
		
		//console.log(text13);
		
		var new1=""
		var new2=""
		
		
		if (text1[6] == "EVP1") {
			text12=10;
			
} else if (text1[6] == "EVP2") {
	text12=10;	
	}
		
		
		if (text12 === undefined) {
			text12=0;
			new1 = text1[9];
			new2 = text13[1];
			}
			

		if (text12 == "R20") {
			text12=0;
		
		if (text1[9] == "1") {new1="OFF"}
		else if (text1[9] == "2") {new1="ON"}
		else if (text1[9] == "0")  {new1="NORMAL"};
		
				if (text13[1] == "1") {new2="OFF"}
		else if (text13[1] == "2") {new2="ON"}
		else if (text13[1] == "0")  {new2="NORMAL"};
									}

		if (text12 == "R21") {
			text12=0;
		if (text1[9] == "0") {new1="OFF"}
		else if (text1[9] == "1") {new1="ON"};
		
		if (text13[1] == "0") {new2="OFF"}
		else if (text13[1] == "1") {new2="ON"};
									}	
									
	
		if (text12 == "R11") {
			text12=0;			
			let word_length = text1[9].length				

let text = text1[9];
var letter=""
if ((text.charAt(0+(word_length-4)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-4))}
if ((text.charAt(0+(word_length-3)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-3))}
letter += ":"
if ((text.charAt(0+(word_length-2)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-2))}
if ((text.charAt(0+(word_length-1)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-1))}
new1= letter;

let text2 = text13[1];
var letter2=""
if ((text.charAt(0+(word_length-4)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-4))}
if ((text.charAt(0+(word_length-3)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-3))}
letter2 += ":"
if ((text.charAt(0+(word_length-2)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-2))}
if ((text.charAt(0+(word_length-1)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-1))}
new2= letter2;									}	


		if (text12 == "R10") {
			text12=0;
			
			let word_length = text1[9].length

let text = text1[9];
var letter=""
if ((text.charAt(0+(word_length-6)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-6))}
if ((text.charAt(0+(word_length-5)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-5))}
letter += ":"
if ((text.charAt(0+(word_length-4)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-4))}
if ((text.charAt(0+(word_length-3)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-3))}
letter += ":"
if ((text.charAt(0+(word_length-2)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-2))}
if ((text.charAt(0+(word_length-1)))==0) {letter += "0"} else {letter += text.charAt(0+(word_length-1))}
new1= letter;

let text2 = text13[1];
var letter2=""
if ((text.charAt(0+(word_length-6)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-6))}
if ((text.charAt(0+(word_length-5)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-5))}
letter2 += ":"
if ((text.charAt(0+(word_length-4)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-4))}
if ((text.charAt(0+(word_length-3)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-3))}
letter2 += ":"
if ((text.charAt(0+(word_length-2)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-2))}
if ((text.charAt(0+(word_length-1)))==0) {letter2 += "0"} else {letter2 += text2.charAt(0+(word_length-1))}
new2= letter2;									}									


			//	console.log(new1);
		

		if (text10 === undefined) {
		text10=text1[6]
		text11="   *No Matched Text Conversion"
		}


  
  var table = document.getElementById("myTable");
  var row = table.insertRow(i+1);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);
  var cell4 = row.insertCell(3);  
  var cell5 = row.insertCell(4);
  
  cell1.innerHTML = "ID:"+(i+1);
  cell2.innerHTML = (text10)+text11;
  cell3.innerHTML = (RAMdata[8]);
  if (text12==0) {
	    cell4.innerHTML = (new1);
	  
  }
  else{
	    cell4.innerHTML = (text1[9]/text12);
  }
  
    if (text12==0) {
	    cell5.innerHTML = (new2);
	  
  }
  else{
	    cell5.innerHTML = (text13[1]/text12);
  }
	  
				//console.log(text1[9]);
  
 // cell4.innerHTML = (text1[9]+text12);
 // cell5.innerHTML = (text13[1]/text12);


  N += 2

}


}	
else {
	var x = document.getElementById("myTable");
	x.style.display = "none";
	var y = document.getElementById("Download_RAM_Text");
	y.style.display = "none";
  
	
	
	
	document.getElementById("demo1").innerHTML = "";	
	}

function convertToPlain(html){

    // Create a new div element
    var tempDivElement = document.createElement("div");

    // Set the HTML content with the given value
    tempDivElement.innerHTML = html;

    // Retrieve the text property of the element 
    return tempDivElement.textContent || tempDivElement.innerText || "";
}


}

/*
function {
document.getElementsByTagName("table")[1].setAttribute("id","tableid");
download_table_as_csv(History);
}
*/


function download_table_as_csv(table_id, separator = ',') {
    // Select rows from table_id
    var rows = document.querySelectorAll('table#' + table_id + ' tr');
    // Construct csv
    var csv = [];
    for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll('td, th');
        for (var j = 0; j < cols.length; j++) {
            // Clean innertext to remove multiple spaces and jumpline (break csv)
            var data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ')
            // Escape double-quote with double-double-quote (see https://stackoverflow.com/questions/17808511/properly-escape-a-double-quote-in-csv)
            data = data.replace(/"/g, '""');
            // Push escaped string
            row.push('"' + data + '"');
        }
        csv.push(row.join(separator));
    }
    var csv_string = csv.join('\n');
    // Download it
    var filename = 'RAM_Text_Data' + '_' + new Date().toLocaleDateString("en-UK") + '.csv';
    var link = document.createElement('a');
    link.style.display = 'none';
    link.setAttribute('target', '_blank');
    link.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv_string));
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}