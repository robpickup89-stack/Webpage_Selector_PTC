﻿// This line is correct by the FMT of an EC-X
// Important to leave the % in front of it.
//
// This must therefore always be requested using the hvi parser
// like so:
//
//      <script type='text/javascript' language='javascript' SRC='/hvi?file=localization.js'></script>
//
// Note to hvi creators: Tags may never be at the beginning of a line (including whitespace) as the url parser 
// 						 sees this as an include statement causing the translation to fail. 
//
% var local_lang = '<tLANGUAGE.SYS/0>';\n

// Fetching the correct language
local_lang = local_lang.toLowerCase();
document.writeln("<script type='text/javascript' src='local_" + local_lang + ".js'></script>");

// Method that translates everything.
function translate(input)
{
    var patt = /[#]{2}([A-Za-z0-9_]{1,100})[#]{2}/

    var result = input;

    while (patt.test(result))
    {
        var key = patt.exec(result)[1];
        var value = key;

        if (typeof local_dict != 'undefined')
        {
            value = local_dict[key];

            if (typeof value == 'undefined')
            {
                value = key;
            }
        }

        result = result.replace(patt, value);
    }

    return result;
}
