﻿//
//Language tags for English
//

var local_dict = new Array();

//Cell IDs
local_dict["CELL_1000"] = "Reset Functions";
local_dict["CELL_1202"] = "Configuration Manager";
local_dict["CELL_1208"] = "Date and Time";
local_dict["CELL_1231"] = "Task time monitoring";
local_dict["CELL_1266"] = "FLIR Cameras";
local_dict["CELL_1373"] = "Reset logbooks";
local_dict["CELL_1502"] = "Current Faults";
local_dict["CELL_1506"] = "Historical Faults";
local_dict["CELL_1512"] = "Phase Operation";
local_dict["CELL_1516"] = "Detection Operation";
local_dict["CELL_1522"] = "Output Operation";
local_dict["CELL_1526"] = "Input Operation";
local_dict["CELL_1532"] = "Parameter Changes";
local_dict["CELL_1535"] = "Dim Monitoring";
local_dict["CELL_1536"] = "Supervisor status";
local_dict["CELL_1537"] = "Leak Monitoring";
local_dict["CELL_1611"] = "XD16 loop settings";
local_dict["CELL_1621"] = "XD16 board settings";
local_dict["CELL_1806"] = "Minimum Green";
local_dict["CELL_1812"] = "Maximum Green";
local_dict["CELL_1818"] = "Intergreens";
local_dict["CELL_1820"] = "Switch On Sequence";
local_dict["CELL_1824"] = "Phase Delays";
local_dict["CELL_1828"] = "PSVP Maximum Green";
local_dict["CELL_1829"] = "PSVP Inhibit Times";
local_dict["CELL_1830"] = "Helper Elements";
local_dict["CELL_1831"] = "PSVP Compensation Times";
local_dict["CELL_1834"] = "Miscellaneous";
local_dict["CELL_1838"] = "All Red Extension";
local_dict["CELL_1842"] = "Pelican";
local_dict["CELL_1846"] = "Standalone Puffin";
local_dict["CELL_1847"] = "Intersection Puffin";
local_dict["CELL_1850"] = "Standalone Toucan Near";
local_dict["CELL_1851"] = "Intersection Toucan Near";
local_dict["CELL_1854"] = "Standalone Toucan Far";
local_dict["CELL_1855"] = "Intersection Toucan Far";
local_dict["CELL_1862"] = "Standalone Pedestrian";
local_dict["CELL_1863"] = "Intersection Pedestrian";
local_dict["CELL_1880"] = "Pedestrian Local-Linking";
local_dict["CELL_2000"] = "Detection";
local_dict["CELL_2001"] = "FLIR Cameras";
local_dict["CELL_2002"] = "Detector Fault Monitoring";
local_dict["CELL_2004"] = "Integral SASD";
local_dict["CELL_2115"] = "Execution";
local_dict["CELL_2117"] = "Reports";
local_dict["CELL_2300"] = "Communications Setup";
local_dict["CELL_2303"] = "UG405";
local_dict["CELL_2304"] = "UG405 Licence ";
local_dict["CELL_2502"] = "Mode Selection";
local_dict["CELL_2504"] = "Timetable";
local_dict["CELL_2506"] = "Timetable Special Days";
local_dict["CELL_2508"] = "CLF Plans";
local_dict["CELL_2562"] = "Hurry Calls";
local_dict["CELL_2570"] = "PSVP Operation";
local_dict["CELL_2572"] = "PSVP Timings";
local_dict["CELL_2702"] = "Event Pulses";
local_dict["CELL_2708"] = "Event Filters";
local_dict["CELL_2716"] = "User Defined Parameters";
local_dict["CELL_2720"] = "General Purpose Timers";
local_dict["CELL_2726"] = "Counters/Memory Elements";
local_dict["CELL_2731"] = "XD16 loop pair settings";
local_dict["CELL_2804"] = "Phases";
local_dict["CELL_2804_TLC"] = "TLC Phases";
local_dict["CELL_2808"] = "Input Status";
local_dict["CELL_2812"] = "Output Status";
local_dict["CELL_2828"] = "Plan Operation";
local_dict["CELL_2832"] = "Lamp Monitoring";
local_dict["CELL_2834"] = "Lamp Monitoring Debug";
local_dict["CELL_2835"] = "Dim Monitoring";
local_dict["CELL_2836"] = "Hardware Status";
local_dict["CELL_2837"] = "Leak Monitoring";
local_dict["CELL_2842"] = "Software Version";
local_dict["CELL_2844"] = "Flash Testing";
local_dict["CELL_2846"] = "Simulate Lamp Faults";
local_dict["CELL_2848"] = "System Flags";
local_dict["CELL_2852"] = "Diagnostics";
local_dict["CELL_2856"] = "Configuration";
local_dict["CELL_2860"] = "Stages Debug";
local_dict["CELL_3230"] = "Certifications";
local_dict["CELL_3240"] = "Certificates";
local_dict["CELL_4000"] = "Settings";
local_dict["CELL_4010"] = "Global settings";
local_dict["CELL_4020"] = "Countdata";
local_dict["CELL_4030"] = "Actual period";
local_dict["CELL_4600"] = "Select VSET";
local_dict["CELL_4610"] = "VSET settings";
local_dict["CELL_4620"] = "View data";
local_dict["CELL_6810"] = "Alert+";
local_dict["CELL_6820"] = "Alert+";
local_dict["CELL_9301"] = "Status OTU 1";
local_dict["CELL_9302"] = "Status OTU 2";
local_dict["CELL_9303"] = "Status OTU 3";
local_dict["CELL_9304"] = "Status OTU 4";
local_dict["CELL_9470"] = "Status";
local_dict["CELL_9471"] = "Diagnostics";
local_dict["CELL_9600"] = "RLCS System/XLM";
local_dict["CELL_9610"] = "RLCS RLU";
local_dict["CELL_9620"] = "RLCS Lamps";
local_dict["CELL_9630"] = "RLCS RIO";
local_dict["CELL_9640"] = "WDS Access Points";
local_dict["CELL_9900"] = "Wait time predictions";

//Menu Titles
local_dict["MENU_001"] = "Home";
local_dict["MENU_002"] = "Functions";
local_dict["MENU_0024"] = "DIF Monitor";
local_dict["MENU_003"] = "Logbooks";
local_dict["MENU_005"] = "Parameters";
local_dict["MENU_0051"] = "System parameters";
local_dict["MENU_0052"] = "Signalgroup timing";
local_dict["MENU_0053"] = "Signalgroup timing";
local_dict["MENU_0054"] = "Public transport";
local_dict["MENU_005a"] = "Parameters";
local_dict["MENU_005b"] = "Parameters";
local_dict["MENU_005c"] = "Parameters";
local_dict["MENU_005d"] = "Parameter";
local_dict["MENU_006"] = "Service";
local_dict["MENU_0061"] = "I/O status";
local_dict["MENU_0062"] = "EuroDetector ED16";
local_dict["MENU_00620"] = "Master/Slave";
local_dict["MENU_0062a"] = "XD16";
local_dict["MENU_0063"] = "Diagnostics";
local_dict["MENU_0064"] = "C-interface monitor";
local_dict["MENU_0065"] = "CCOL State";
local_dict["MENU_0066"] = "Plan";
local_dict["MENU_0067"] = "CPU-C";
local_dict["MENU_00612"] = "Supervisortest";
local_dict["MENU_007"] = "Traffic data";
local_dict["MENU_0071"] = "Count program";
local_dict["MENU_0072"] = "TDC";
local_dict["MENU_0073"] = "CCS Count program";
local_dict["MENU_012"] = "Setup";
local_dict["MENU_015"] = "Logbooks";
local_dict["MENU_018"] = "Phase Timings";
local_dict["MENU_020"] = "Detection";
local_dict["MENU_023"] = "Communications";
local_dict["MENU_025"] = "Operational Modes";
local_dict["MENU_027"] = "User Defined Params";
local_dict["MENU_028"] = "Maintenance";


//Language tags
local_dict["T_1STLAMPFAIL"] = "1st Lamp Fail";
local_dict["T_2NDLAMPFAIL"] = "2nd Lamp Fail";
local_dict["T_A"] = "Current";
local_dict["T_A_MA"] = "Current [mA]";
local_dict["T_MCRA"] = "Act. current [mA]";
local_dict["T_MNCR"] = "Nom. current [mA]";
local_dict["T_MNCRA"] = "Nom. current [mA]";
local_dict["T_A1"] = "A1";
local_dict["T_A2"] = "A2";
local_dict["T_A3"] = "A3";
local_dict["T_A4"] = "A4";
local_dict["T_ABSENCE"] = "Absence";
local_dict["T_ABS_MARGIN_W"] = "Abs. margin [W]";
local_dict["T_ACTION"] = "Action";
local_dict["T_ACTIVE"] = "Active";
local_dict["T_ACTIVEVSET"] = "Active VSET";
local_dict["T_ACTUAL"] = "Actual";
local_dict["T_ACTUALCLOCK"] = "Actual clock";
local_dict["T_ADDRESS"] = "address";
local_dict["T_ALARMS"] = "Alarms";
local_dict["T_ALERT_PROTOCOL_VERSION"] = "Protocol version";
local_dict["T_ALLSTRMS"] = "All Streams";
local_dict["T_ALPHADOWN"] = "Alpha down";
local_dict["T_ALPHAUP"] = "Alpha up";
local_dict["T_ALTMAXTIMING"] = "Alternative maximum timing";
local_dict["T_ARDD"] = "All Red Demand Delay";
local_dict["T_ARG1"] = "ARG1";
local_dict["T_ARG2"] = "ARG2";
local_dict["T_ARGUMENT"] = "Argument";
local_dict["T_ASPECT"] = "Aspect";
local_dict["T_ASSPH"] = "Assoc Phase";
local_dict["T_AVAILABLEPROGRAMS"] = "Configurations Available";
local_dict["T_BACKUPCHOICE"] = "Backup Configuration";
local_dict["T_BASETIME"] = "Base time"
local_dict["T_BASEDATE"] = "Base date";
local_dict["T_BASETIME_REF"] = "Base time reference";
local_dict["T_REFTYPE"] = "Reference type";
local_dict["T_BEGIN"] = "Begin";
local_dict["T_BLANK"] = "";
local_dict["T_BMAINS"] = "BMAINS";
local_dict["T_BTN_BACK"] = "Back";
local_dict["T_BTN_EDIT_1"] = "View";
local_dict["T_BTN_EDIT_2"] = "Edit";
local_dict["T_BTN_REFRESH_1"] = "Refresh";
local_dict["T_BTN_REFRESH_2"] = "Freeze";
local_dict["T_BUSLINE"] = "Busline";
local_dict["T_BYTESBEFORERTS"] = "Bytes before RTS";
local_dict["T_CALIBPOWER"] = "Calibrated Lamps";
local_dict["T_CATEGORY"] = "Category";
local_dict["T_CCOLSTATE"] = "CCOL state";
local_dict["T_CC_IDX"] = "CC Index";
local_dict["T_CFL"] = "CFL";
local_dict["T_CLFSELECT"] = "Select a CLF Plan to View / Edit";
local_dict["T_CHGMODE"] = "Change FXT/VA/RVT";
local_dict["T_CIRC"] = "Circ";
local_dict["T_CIRCUIT"] = "Circuit";
local_dict["T_CLFPLAN"] = "CLF Plan";
local_dict["T_CLF_OPERATION"] = "CLF Operation";
local_dict["T_CLICK"] = "Click";
local_dict["T_CLOCK"] = "CLOCK";
local_dict["T_CNTNOTAVAI"] = "The count program is not available.";
local_dict["T_COMSET"] = "Common settings";
local_dict["T_CONFIGCHANGE"] = "Config Change";
local_dict["T_CONFIGURATION"] = "Configuration";
local_dict["T_CONFIGURED"] = "Conf.";
local_dict["T_CONFIGVER"] = "Configuration Version";
local_dict["T_CONNECTION"] = "Connection";
local_dict["T_CONTINUE"] = "CONTINUE";
local_dict["T_COUNT"] = "Count";
local_dict["T_COUNTER"] = "Counter";
local_dict["T_CPULOAD"] = "CPU load";
local_dict["T_CPUVOLT"] = "CPU voltage";
local_dict["T_CURRENTPROGRAM"] = "Active Configuration";
local_dict["T_CURRENT_APPL_SLOT"] = "Active application slot";
local_dict["T_CURRSTAGE"] = "Current Stage";
local_dict["T_CYCLETIME"] = "Cycle time";
local_dict["T_D1"] = "D1";
local_dict["T_D2"] = "D2";
local_dict["T_DATA"] = "Data";
local_dict["T_DATE"] = "Date";
local_dict["T_DATETIME"] = "Date/Time";
local_dict["T_DAY"] = "Day";
local_dict["T_DCL"] = "DCL";
local_dict["T_DCN"] = "DCN";
local_dict["T_DEFAULT"] = "Default";
local_dict["T_DEGREES"] = "degrees";
local_dict["T_DELTYPE"] = "Delay Type";
local_dict["T_DEMAND"] = "Demand";
local_dict["T_DESCRIPTION"] = "Description";
local_dict["T_DETBUT"] = "Click to reset detectors";
local_dict["T_DETECTION"] = "Detection";
local_dict["T_DETECTIONHIS"] = "Detection (his)";
local_dict["T_DETECTOR"] = "Detector";
local_dict["T_DFX"] = "DFX";
local_dict["T_DFY"] = "DFY";
local_dict["T_DHC"] = "Hurry Call Delay";
local_dict["T_DIAGNOSTICINFO"] = "Diagnostic info";
local_dict["T_DIM_ERROR"] = "Dim error";
local_dict["T_DISABLED"] = "Disabled";
local_dict["T_DS"] = "DS";
local_dict["T_DSI"] = "DSI";
local_dict["T_DONGLE"] = "Dongle";
local_dict["T_DURATION"] = "Duration";
local_dict["T_EBO"] = "EBO";
local_dict["T_EDIT"] = "edit";
local_dict["T_EMERGENCY"] = "Emergency program";
local_dict["T_EMPTY_LOGBOOK"] = "No logbook messages";
local_dict["T_ENABLED"] = "Enabled";
local_dict["T_END"] = "End";
local_dict["T_ENTER_CFT"] = "Enter TEST mode";
local_dict["T_ENTRIES"] = "Entries";
local_dict["T_ENTRYTIME"] = "Plan Entry Time";
local_dict["T_ERRBUT"] = "Click to reset errors";
local_dict["T_ERRINFO"] = "There is a problem with the request.";
local_dict["T_ERRSTATUS"] = "Error status";
local_dict["T_ETHCONF"] = "Ethernet configuration";
local_dict["T_EXITTIME"] = "Plan Exit Time";
local_dict["T_EXECUTE"] = "Execute";
local_dict["T_EXIT_CFT"] = "Leave test mode";
local_dict["T_EXT"] = "Extension";
local_dict["T_EXTREDTSETS"] = "Period 6 Extended Red Timing Sets";
local_dict["T_EXT_TMR"] = "Ext Timer";
local_dict["T_EXT_TYPE"] = "Ext Type";
local_dict["T_FAULT"] = "Fault";
local_dict["T_FAULTHIS"] = "Fault (his)";
local_dict["T_FAULTMON"] = "Fault Monitoring";
local_dict["T_FAULTS"] = "Faults";
local_dict["T_FC"] = "FC";
local_dict["T_FCT"] = "FCT";
local_dict["T_FCT_DA"] = "FCT_DA";
local_dict["T_FCT_S"] = "FCT_S";
local_dict["T_FCX"] = "Forced Red Extension";
local_dict["T_FLAG"] = "Flag";
local_dict["T_FLAGS"] = "Flags";
local_dict["T_FORCE"] = "force";
local_dict["T_FORCECLF"] = "Force CLF";
local_dict["T_FORCEHC"] = "Force HC";
local_dict["T_FREQ"] = "Freq";
local_dict["T_FROM"] = "From";
local_dict["T_FTST_AUTO_OFF"] = "Stop autotest";
local_dict["T_FTST_AUTO_ON"] = "Start autotest";
local_dict["T_FTST_AUTOTEST"] = "Autotest";
local_dict["T_FTST_CASES_OVERVIEW"] = "Test overview";
local_dict["T_FTST_CASES_TOTAL"] = "Total";
local_dict["T_FTST_CASES_SUCCESS"] = "Success";
local_dict["T_FTST_CASES_ERROR"] = "Error";
local_dict["T_FTST_CASES_TODO"] = "To do";
local_dict["T_FTST_CAUSE"] = "Suggestion";
local_dict["T_FTST_CONFIRM"] = "Confirm";
local_dict["T_FTST_DIM_OFF"] = "Switch to bright";
local_dict["T_FTST_DIM_ON"] = "Switch to dimming";
local_dict["T_FTST_DONGLE_INSERT"] = "Dongle required";
local_dict["T_FTST_DONGLE_LOGIN"] = "Dongle login level 2 required";
local_dict["T_FTST_ENTER"] = "Enter FLASHTEST mode";
local_dict["T_FTST_EXECUTE_CONTROLS"] = "Lamp switches";
local_dict["T_FTST_EXECUTE_SPARES"] = "Spare switches";
local_dict["T_FTST_EXECUTE_OUTPUTS"] = "Outputs";
local_dict["T_FTST_EXIT"] = "Leave FLASHTEST mode";
local_dict["T_FTST_MIMIC"] = "Mimic mode";
local_dict["T_FTST_REPORTS"] = "Reports";
local_dict["T_FTST_RESET_ERRORS"] = "Reset errors";
local_dict["T_FTST_STATECTRL"] = "Flashtest control state";
local_dict["T_FTST_STATESERV"] = "Flashtest service state";
local_dict["T_FTST_STATESYS"] = "Flashtest system summary";
local_dict["T_FTST_SUPERTEST"] = "Supervisortest";
local_dict["T_FTST_DURATION"] = "Flash duration [sec]";
local_dict["T_FTST_TITLE"] = "Flashtest";
local_dict["T_FUNCLOGIN"] = "Other functies are available after login";
local_dict["T_FUNCNOTAVAI"] = "This function is not available.";
local_dict["T_FUNCTION"] = "Function";
local_dict["T_GAP"] = "gap";
local_dict["T_GAP1"] = "GAP1";
local_dict["T_GAP2"] = "GAP2";
local_dict["T_GATEWAY"] = "Default gateway";
local_dict["T_GB1"] = "GB1";
local_dict["T_GB2"] = "GB2";
local_dict["T_GB3"] = "GB3";
local_dict["T_GB4"] = "GB4";
local_dict["T_GE1"] = "GE1";
local_dict["T_GE2"] = "GE2";
local_dict["T_GE3"] = "GE3";
local_dict["T_GE4"] = "GE4";
local_dict["T_GL"] = "GL";
local_dict["T_GO"] = "Go";
local_dict["T_GPMEM"] = "General Purpose Memory";
local_dict["T_GPS"] = "GPS";
local_dict["T_GPVAL"] = "Current Value of General Purpose Counter";
local_dict["T_GREENMAN"] = "Period 4 Green Man Timing Sets";
local_dict["T_GROUP"] = "Group";
local_dict["T_GUS"] = "GUS";
local_dict["T_HC"] = "Hurry Call";
local_dict["T_HCSTATUS"] = "Hurry Call Status";
local_dict["T_HELP"] = "Help";
local_dict["T_HHC"] = "Hurry Call Hold";
local_dict["T_HOLD"] = "Hold";
local_dict["T_HOLD_OFF_PERIOD_MIN"] = "Hold off bright request - period [min]";
local_dict["T_HOLD_OFF_TIME_S"] = "Hold off bright request - remaining time [sec]";
local_dict["T_ID"] = "Id";
local_dict["T_IGEXTENSION"] = "IG Ext Reason";
local_dict["T_IGN"] = "IGN";
local_dict["T_IGNEXT"] = "IGN EXT";
local_dict["T_IMAGEVALIDTIME"] = "Image valid time [sec]";
local_dict["T_IN"] = "In";
local_dict["T_INCOMING"] = "Incoming";
local_dict["T_INCSCOOT"] = "Include SCOOT";
local_dict["T_IND"] = "Ind";
local_dict["T_INDEX"] = "Index";
local_dict["T_INFLUENCE"] = "Influence";
local_dict["T_INPUT"] = "Input";
local_dict["T_INTERS"] = "Junction Name";
local_dict["T_INTERSCAN"] = "Interscan";
local_dict["T_INVBITS"] = "Invert Control/Reply Bits";
local_dict["T_INVSTATE"] = "Invert State";
local_dict["T_IPADDRESS"] = "IP address";
local_dict["T_IS"] = "IS";
local_dict["T_LAMPFAULTBUT"] = "Click to reset lamp faults";
local_dict["T_LAMPFAULTBUTSRM2"] = "Click to reset SRM2 lamp faults";
local_dict["T_LAMPS"] = "Lamp";
local_dict["T_LAST_BRIGHT_W"] = "Last bright [W]";
local_dict["T_LCL"] = "LCL";
local_dict["T_LDIM"] = "L.dim";
local_dict["T_LEAK_ERROR"] = "Leak error";
local_dict["T_LEV3ACC"] = "Level 3 Access";
local_dict["T_LEV3TOUT"] = "LEVEL3 Timeout";
local_dict["T_LINK"] = "Link";
local_dict["T_LOCATION"] = "Location";
local_dict["T_LOG"] = "Log";
local_dict["T_LOGIN"] = "Login";
local_dict["T_LOGINLEVEL"] = "Login level";
local_dict["T_LOOP"] = "Loop";
local_dict["T_LOOPPAIR"] = "Loop pair";
local_dict["T_LOOPSEP"] = "Loop Separation";
local_dict["T_LSPC"] = "L.spc";
local_dict["T_LSPEED"] = "Last Speed (mph)";
local_dict["T_MACADDRESS"] = "MAC address";
local_dict["T_MAINS"] = "Mains";
local_dict["T_MANSTEP"] = "Manual Step";
local_dict["T_MAN_PANEL"] = "Manual Panel";
local_dict["T_MAX"] = "Max";
local_dict["T_MBO"] = "MBO";
local_dict["T_MDU"] = "MDU";
local_dict["T_MF"] = "MF";
local_dict["T_MIMIC"] = "Mimic";
local_dict["T_MIMICMODE"] = "Mimic mode \= on";
local_dict["T_MIMICVIEWER"] = "Mimic Viewer";
local_dict["T_MIMMODEBUT"] = "Mimic mode";
local_dict["T_MIN"] = "Min";
local_dict["T_MINGREEN"] = "Minimum green";
local_dict["T_MNR"] = "Minimum Red";
local_dict["T_MODE"] = "Mode";
local_dict["T_MS_ISMASTER"] = "Is master:";
local_dict["T_MS_PROTOCOL_STS"] = "Protocol status:";
local_dict["T_MS_COMMUNICATION_OK"] = "Communication status:";
local_dict["T_MS_CONFIGURATION_OK"] = "Configuration status:";
local_dict["T_MS_PROXY_CONF_OK"] = "Proxy Configuration status:";
local_dict["T_MS_PROXY_COUNT"] = "Proxy count:";
local_dict["T_MVNOTAVAI"] = "The MV files are not available";
local_dict["T_NAME"] = "Name";
local_dict["T_NO"] = "NO";
local_dict["T_NO_PAR_CHANGES"] = "No parameter changes";
local_dict["T_NR"] = "NR";
local_dict["T_OCCUPIED"] = "Occupied";
local_dict["T_OFF"] = "OFF";
local_dict["T_OFFSET"] = "Offset";
local_dict["T_ON"] = "ON";
local_dict["T_OTU"] = "OTU";
local_dict["T_OUT"] = "Out";
local_dict["T_OUTGOING"] = "Outgoing";
local_dict["T_OUTPUT"] = "Output";
local_dict["T_OVERRIDE"] = "Override";
local_dict["T_OVERVIEW"] = "Overview";
local_dict["T_P"] = "Power [W]";
local_dict["T_PAM"] = "PAM";
local_dict["T_PARM"] = "PARM";
local_dict["T_PBT"] = "Pedestrian Blackout";
local_dict["T_PED"] = "Pedestrian";
local_dict["T_PED1"] = "Use veh min max greens";
local_dict["T_PED3EXT"] = "Use IGN EXT in table below";
local_dict["T_PED3IGN"] = "Use v->p IGN in table below";
local_dict["T_PEDIGN"] = "Use v->p IGN in table below";
local_dict["T_PEDIGNEXT"] = "Use IGN EXT in table below";
local_dict["T_PEDPERIOD2_3"] = "Periods 2 and 3 v->p IGN and IGN extension";
local_dict["T_PERIOD"] = "Period";
local_dict["T_PERIODTYPE"] = "Period type";
local_dict["T_PH"] = "PH";
local_dict["T_PHC"] = "Hurry Call Prevent";
local_dict["T_PLAN"] = "Plan";
local_dict["T_PLSG"] = "PL,SG";
local_dict["T_PRESENCE"] = "Presence";
local_dict["T_PRIORITYCOMP"] = "Priority Compensation(PQA)";
local_dict["T_PRIORITYINHIB"] = "Priority Inhibition(PIA)";
local_dict["T_PRIORITYMAX"] = "Priority Maximum(PMA)";
local_dict["T_PROGRAM"] = "Program";
local_dict["T_PROGRAMCHOICE"] = "Selected Configuration";
local_dict["T_PROGTODSELECT"] = "Program TOD selection";
local_dict["T_PROVIDER"] = "Provider";
local_dict["T_PROVIDERTYPE"] = "Provider type";
local_dict["T_PROXY"] = "Proxy";
local_dict["T_REASON"] = "Reason";
local_dict["T_REBOOTBUT"] = "Click to reboot";
local_dict["T_REBOOTMSG"] = "Rebooting will cause the controller to shutdown. Do you really want to reboot?";
local_dict["T_RECALIB"] = "Re-calibrate";
local_dict["T_RECALIBLAMPS"] = "Recalibrate all Lamps";
local_dict["T_REF1"] = "Lamp Units";
local_dict["T_REF1_W"] = "REF1 [W]";
local_dict["T_REF2"] = "REF2";
local_dict["T_REFHI"] = "Ref hi";
local_dict["T_REFLO"] = "Ref lo";
local_dict["T_REFRESH"] = "refresh";
local_dict["T_REFSTAT"] = "Status in Relation to Reference";
local_dict["T_REFVAL"] = "Reference Value";
local_dict["T_REL_MARGIN_PCT"] = "Rel. margin [%]";
local_dict["T_REPETITION"] = "Rep";
local_dict["T_REPORT"] = "Report";
local_dict["T_REPTIME"] = "Repetition time";
local_dict["T_RESET"] = "Reset";
local_dict["T_RESETABLE"] = "Resetable";
local_dict["T_RESTORETMT"] = "Restore timetable to config";
local_dict["T_RLCS_BMAINS_FREQ"] = "BMAINS Frequency";
local_dict["T_RLCS_CHAIN"] = "chain";
local_dict["T_RLCS_COMMAND"] = "Command [ON/OFF]";
local_dict["T_RLCS_CONF_RLU"] = "Configured RLU Count";
local_dict["T_RLCS_DETECTED_BY"] = "Detected by";
local_dict["T_RLCS_DETECTED_RLU"] = "Actual RLU Count";
local_dict["T_RLCS_DISCOVERY_STATE"] = "Discovery State";
local_dict["T_RLCS_HERTZ"] = "Hz";
local_dict["T_RLCS_INPUT_VOLT"] = "Input Voltage [V]";
local_dict["T_RLCS_LCM_COUNT"] = "LCM Count";
local_dict["T_RLCS_FILTERED_ERROR_COUNTER"] = "Filtered error count";
local_dict["T_RLCS_MISSED_MESG"] = "Missed";
local_dict["T_RLCS_RIO_NO_SPARE_RIO"] = "No unconfigured RIOs found";
local_dict["T_RLCS_RLU"] = "RLU";
local_dict["T_RLCS_SELECTED_RLU"] = "Selected RLU";
local_dict["T_RLCS_TEMPERATURE"] = "Temperature [C]";
local_dict["T_RLCS_UNCONFIGURED"] = "UNCONFIGURED";
local_dict["T_RSTART"] = "R.Start";
local_dict["T_RSTOP"] = "R.Stop";
local_dict["T_RTS"] = "RTS";
local_dict["T_RX"] = "RX";
local_dict["T_RX_CNT"] = "RX";
local_dict["T_S"] = "Calibration";
local_dict["T_SAFEMIN"] = "Safety Minimum";
local_dict["T_SAFETY"] = "Safety";
local_dict["T_SCOOTDET"] = "SCOOT Detectors";
local_dict["T_SECONDS"] = "Seconds";
local_dict["T_SELECTALL"] = "Select all";
local_dict["T_SELECTED"] = "Selected";
local_dict["T_SENS"] = "Sens";
local_dict["T_SERIALCONF"] = "Serial Port Configuration";
local_dict["T_SET"] = "Set";
local_dict["T_SF_BRTR"] = "Bright request";
local_dict["T_SF_DIMA"] = "Dim activation";
local_dict["T_SF_DIMR"] = "Dim request";
local_dict["T_SG"] = "Phase";
local_dict["T_SIGNAL"] = "Signal";
local_dict["T_SIGNALGROUP"] = "Signalgroup";
local_dict["T_SIMFAULT"] = "Simulate Lamp Faults";
local_dict["T_SIMSPEED"] = "Set Veh Speed (mph)";
local_dict["T_SITEENG"] = "Site Engineer";
local_dict["T_SITEVIEW"] = "SiteView";
local_dict["T_SON"] = "On/Off/Flash";
local_dict["T_SOREF"] = "SoRef";
local_dict["T_SOS"] = "SOS";
local_dict["T_SOURCE"] = "Source";
local_dict["T_SPECGROUPS"] = "Special Groups";
local_dict["T_SPEEDEXT"] = "Speed Extension";
local_dict["T_SPEED_DETECTION"] = "SO_V (km/h)";
local_dict["T_SPEED_REF"] = "SO_REF (km/h)";
local_dict["T_SPOT"] = "Spot";
local_dict["T_SRM2"] = "SRM2";
local_dict["T_STAGE"] = "Stage";
local_dict["T_START"] = "Start";
local_dict["T_STARTDATE"] = "Start date";
local_dict["T_STARTTIME"] = "Start time";
local_dict["T_STARTSTAGE"] = "In Start Stage";
local_dict["T_STATE"] = "State";
local_dict["T_STATUS"] = "Status";
local_dict["T_STREAM"] = "Stream";
local_dict["T_SUBNETMASK"] = "Subnet mask";
local_dict["T_SWICO"] = "Override";
local_dict["T_SWITCH"] = "Switch";
local_dict["T_SYSTEMVOLT"] = "System voltage";
local_dict["T_TA"] = "TA";
local_dict["T_TBG"] = "TBG";
local_dict["T_TDB"] = "TDB";
local_dict["T_TDBG"] = "TDBG";
local_dict["T_TDCNOTAVAI"] = "The TDC files are not available";
local_dict["T_TDH"] = "TDH";
local_dict["T_TDH1"] = "TDH1";
local_dict["T_TDH11"] = "TDH11";
local_dict["T_TDH12"] = "TDH12";
local_dict["T_TDH2"] = "TDH2";
local_dict["T_TDH21"] = "TDH21";
local_dict["T_TDH22"] = "TDH22";
local_dict["T_TDOG"] = "TDOG";
local_dict["T_TEG1"] = "TEG1";
local_dict["T_TEG2"] = "TEG2";
local_dict["T_TELEPHONE"] = "telephone";
local_dict["T_TEMPERATURE"] = "Temperature";
local_dict["T_TEMPCPU"] = "Temperature (CPU)";
local_dict["T_TEST"] = "TEST";
local_dict["T_TEST_SELECTION"] = "Test selection";
local_dict["T_TFG"] = "TFG";
local_dict["T_TFL"] = "TFL";
local_dict["T_TG"] = "TG";
local_dict["T_TGA"] = "TGA";
local_dict["T_TGG"] = "TGG";
local_dict["T_TGGL"] = "TGGL";
local_dict["T_TGL"] = "TGL";
local_dict["T_TGR"] = "TGR";
local_dict["T_THRESHOLD_W"] = "Threshold [W]";
local_dict["T_TI"] = "TI";
local_dict["T_TIME"] = "Time";
local_dict["T_TIMER"] = "Timer";
local_dict["T_TIMVAL"] = "Timer Value";
local_dict["T_TING"] = "TING";
local_dict["T_TINR"] = "TINR";
local_dict["T_TLAT"] = "TLAT";
local_dict["T_TLST"] = "TLST";
local_dict["T_TMG"] = "TMG";
local_dict["T_TMG1"] = "TMG1";
local_dict["T_TMG2"] = "TMG2";
local_dict["T_TMG3"] = "TMG3";
local_dict["T_TMG4"] = "TMG4";
local_dict["T_TMG5"] = "TMG5";
local_dict["T_TMG6"] = "TMG6";
local_dict["T_TNEC"] = "TNEC";
local_dict["T_TO"] = "To";
local_dict["T_TOG"] = "TOG";
local_dict["T_TOGGLE"] = "TOGGLE";
local_dict["T_TPDD"] = "Pedestrian Demand Delay";
local_dict["T_TRA"] = "TRA";
local_dict["T_TRG"] = "TRG";
local_dict["T_TSET"] = "Timing Set";
local_dict["T_TVG"] = "TVG";
local_dict["T_TX"] = "TX";
local_dict["T_TX_CNT"] = "TX";
local_dict["T_TXA"] = "TXA";
local_dict["T_TXB"] = "TXB";
local_dict["T_TXC"] = "TXC";
local_dict["T_TXD"] = "TXD";
local_dict["T_TXE"] = "TXE";
local_dict["T_TXTIM"] = "Cycle timer";
local_dict["T_TYPE"] = "Type";
local_dict["T_UG405COMM"] = "SNMP UG405 Communication";
local_dict["T_UNIT"] = "Unit";
local_dict["T_UPDATE_INTERVAL"] = "Update interval [100ms]";
local_dict["T_USEBELOW"] = "Use table below";
local_dict["T_V"] = "Voltage";
local_dict["T_V_V"] = "Voltage [V]";
local_dict["T_VALID"] = "Valid";
local_dict["T_VALUE"] = "Value";
local_dict["T_VAR"] = "VAR";
local_dict["T_VBO"] = "VBO";
local_dict["T_VERSION"] = "Version";
local_dict["T_VNUMBER"] = "Configuration Id Number";
local_dict["T_VOLT"] = "volt";
local_dict["T_VRIID"] = "Controller Serial No.";
local_dict["T_VSET"] = "VSET";
local_dict["T_VTG"] = "VTG";
local_dict["T_WEBPAGES"] = "Web Pages";
local_dict["T_WORKSWITCH"] = "Workswitch \= on";
local_dict["T_WPS"] = "WPS";
local_dict["T_WUS"] = "WUS";
local_dict["T_YEAR"] = "Year";
local_dict["T_YES"] = "YES";
local_dict["T_ZAP"] = "Zap";
local_dict["T_OTU"] = "OTU";
local_dict["T_OTU_TYPE"] = "OTU Type";
local_dict["T_INVBITS"] = "Invert Control/Reply Bits";
local_dict["T_OTU_CBIT"] = "Control bit";
local_dict["T_OTU_RBIT"] = "Reply bit";
local_dict["T_OTU_STATUS"] = "Status";
local_dict["T_UG405_OPMODE"] = "UG405 Operational mode";
local_dict["T_UG405_CONFIG"] = "UG405 Configuration";
local_dict["T_UG405_SCN"] = "SCN";
local_dict["T_UG405_BIT"] = "UG405 bit";
local_dict["T_SCOOT_DET"] = "SCOOT Detectors";
local_dict["T_SCOOT_ORDER"] = "Order 2-1-4-3-6-5-8-7";
local_dict["T_SYNCMODE"] = "Sync. Mode";
local_dict["T_SYNCDAY"] = "Sync. Day";
local_dict["T_MASK"] = "Mask";


/**************************/
/* FlowNode generic names */
/**************************/

local_dict["T_FLOWNODE"] = "FlowNode";

local_dict["T_PERINET"] = "PERInet";
local_dict["T_SAFENET"] = "SAFEnet";
local_dict["T_SLOT"] = "Slot";
local_dict["T_IDENTIFY_ACTIVE"] = "Identify active";

local_dict["CELL_TOPOLOGY_SIGN"]     = "Sign Topology";
local_dict["CELL_TOPOLOGY_WITHDRAW"] = "Withdraw Topology";
local_dict["CELL_TOPOLOGY_CONFIRM"]  = "Confirm Topology";
local_dict["CELL_TOPOLOGY_VALIDATE"] = "Validate Topology";

local_dict["T_FLOWNODE_UNIT_XSER6"] = "XSER6";
local_dict["T_TX_PORT"] = "TX Port";
local_dict["T_RX_PORT"] = "RX Port";

/**************************/
/* PERInet names          */
/**************************/
local_dict["MENU_PERINET"] = "PERInet";
local_dict["CELL_PERINET_LOGBOOK"] = "PERInet"
local_dict["PERINET_DISCOVERY"] = "Topology Discovery";
local_dict["PERINET_CONFIG"] = "Topology Configuration";
local_dict["PERINET_CONFIRM_MESSAGE"] = "PERInet Topology changed. Confirmation is necessary!";

/**************************/
/* SAFEnet names          */
/**************************/
local_dict["MENU_SAFENET"] = "SAFEnet";
local_dict["CELL_SAFENET_LOGBOOK"] = "SAFEnet";
local_dict["SAFENET_DISCOVERY"] = "Topology Discovery";
local_dict["SAFENET_CONFIG"] = "Topology Configuration";
local_dict["SAFENET_CONFIRM_MESSAGE"] = "SAFEnet Topology changed. Confirmation is necessary!";

/* Protocol names */
local_dict["SAFENET_STAMP"] = "STaMP";
local_dict["SAFENET_SANSA"] = "SaNSa";
local_dict["SAFENET_SCAMPI"] = "SCaMPi";
local_dict["SAFENET_SCAMPI_LCM"] = "SCaMPi LCM";

/* Method names */
local_dict["SAFENET_DISCOVER"] = "Discover";
local_dict["SAFENET_FOUND"] = "Found";
local_dict["SAFENET_MONIX"] = "Monix";
local_dict["SAFENET_CONSISTENCY"] = "Consistency Check";
local_dict["SAFENET_TOPOLOGY"] = "Topology";
local_dict["SAFENET_TICK"] = "Tick";
local_dict["SAFENET_TOCK"] = "Tock";
local_dict["SAFENET_ERROR"] = "Error";
local_dict["SAFENET_PING"] = "Ping";
local_dict["SAFENET_PONG"] = "Pong";
local_dict["SAFENET_NETOK"] = "Network OK";
local_dict["SAFENET_NETNOK"] = "Network Not OK";
local_dict["SAFENET_IDENTIFY"] = "Identify";

local_dict["SAFENET_STATE"] = "State";
local_dict["SAFENET_OVERVIEW"] = "Overview";
local_dict["SAFENET_NODE_AB"] = "A/B";
local_dict["SAFENET_IS_PIP"] = "Is PIP";
local_dict["SAFENET_IS_SPEAKER"] = "Is Speaker";
local_dict["SAFENET_SUPERVISOR"] = "Supervisor";

/* STaMP */
local_dict["SAFENET_STAMP_ETHERNET"] = "Ethernet";
local_dict["SAFENET_STAMP_ETHERNET_COUNTERS"] = "Ethernet counters";

local_dict["SAFENET_STAMP_GIB"] = "GIB";

local_dict["SAFENET_STAMP_GIB_BNA"] = "Buffer NA";
local_dict["SAFENET_STAMP_GIB_RXOVR"] = "Rx Overrun";

local_dict["SAFENET_STAMP_MIB"] = "MIB";

local_dict["SAFENET_STAMP_MIB_PORT_EXTA"] = "ExtA";
local_dict["SAFENET_STAMP_MIB_PORT_EXTB"] = "ExtB";
local_dict["SAFENET_STAMP_MIB_PORT_UCB"] = "uCB";
local_dict["SAFENET_STAMP_MIB_PORT_UCA"] = "uCA";

local_dict["SAFENET_STAMP_MIB_ERRORS"] = "Errors";
local_dict["SAFENET_STAMP_MIB_COLLISIONS"] = "Collisions";
local_dict["SAFENET_STAMP_MIB_RX_DROPS"] = "Rx Dropped";
local_dict["SAFENET_STAMP_MIB_TX_DROPS"] = "Tx Dropped";
local_dict["SAFENET_STAMP_MIB_RX_RATE"] = "Rx Rate [kbps]";
local_dict["SAFENET_STAMP_MIB_TX_RATE"] = "Tx Rate [kbps]";

/* SaNSa */
local_dict["SAFENET_SANSA_LEARN"] = "Learn";
local_dict["SAFENET_SANSA_BUDDY"] = "Buddy";
local_dict["SAFENET_SANSA_ERROR"] = "Error";
local_dict["SAFENET_PRIMARY_ERROR"] = "Primary";
local_dict["SAFENET_SECONDARY_ERROR"] = "Secondary";

/* SCaMPi */
local_dict["SAFENET_SHOT"] = "Shot";
local_dict["SAFENET_FIREWORKS_MAX"] = "Fireworks Max";
local_dict["SAFENET_FIREWORKS_AVG10"] = "Fireworks avg 10";
local_dict["SAFENET_FIREWORKS_AVG100"] = "Fireworks avg 100";
local_dict["SAFENET_SCAMPI_ERROR"] = "Error";
local_dict["SAFENET_SCAMPI_LCM"] = "LCM";

/* Counter */
local_dict["SAFENET_STARTUP_CNT"] = "Startup";
local_dict["SAFENET_EEPROM_CNT"] = "EEPROM";
local_dict["SAFENET_SWITCH_CNT"] = "SW";

/* Supervisor*/
local_dict["SAFENET_SUP_ACS_BCS_CNT"] = "ACS/BCS/CNT";
local_dict["SAFENET_SUP_NAT1"] = "NAT1 Table";
local_dict["SAFENET_SUP_NAT2"] = "NAT2 Table";
local_dict["SAFENET_SUP_NAT1_DIM"] = "NAT1 DIM Table";
local_dict["SAFENET_SUP_NAT2_DIM"] = "NAT2 DIM Table";
local_dict["SAFENET_SUP_LANC"] = "NAT LANC Table";
local_dict["SAFENET_SUP_LOG"] = "Log";
local_dict["SAFENET_SUP_SYS_INFO"] = "System Diag & Info";
local_dict["SAFENET_SUP_IO"] = "I/O";
local_dict["SAFENET_SUP_TIMESET"] = "Timeset";
local_dict["SAFENET_SUP_LOV"] = "LOV";

/**************************/
/* TLC-FI names           */
/**************************/

// iTLC - cells
local_dict["CELL_ITLC_TLC"] = "TLC";
local_dict["CELL_ITLC_APP"] = "Applications";
local_dict["CELL_ITLC_APP_DIAG"] = "Application diagnostics";
local_dict["CELL_ITLC_XP"]  = "Intersections";
local_dict["CELL_ITLC_SG"]  = "Signal groups";
local_dict["CELL_ITLC_SG_PREDICTIONS"] = "Signal group predictions";
local_dict["CELL_ITLC_DET"] = "Detectors";
local_dict["CELL_ITLC_DET_EVENTS"] = "Detector events";
local_dict["CELL_ITLC_IN"]  = "Inputs";
local_dict["CELL_ITLC_OUT"] = "Outputs";
local_dict["CELL_ITLC_VAR"] = "Variables";
local_dict["CELL_ITLC_VEH_EVENTS"] = "SpecialVehicle events";
local_dict["CELL_ITLC_SG_TIMES"] = "Signal group times";
local_dict["CELL_ITLC_SG_CONFLICT"] = "Clearance times";
local_dict["CELL_ITLC_SPECIAL_DAY"] = "Special days";
local_dict["CELL_ITLC_LOGBOOK"] = "TLC-FI";

// iTLC - general
local_dict["T_TLCFI"]            = "TLC-FI";
local_dict["MENU_ITLC"]          = "TLC-FI";
local_dict["T_ITLC_STATE"]       = "Status";
local_dict["T_ITLC_REQ_STATE"]   = "Requested state";
local_dict["T_ITLC_TICK"]        = "Tick";
local_dict["T_ITLC_SWICO"]       = "SWICO";
local_dict["T_ITLC_FAULT_STATE"] = "Fault status";
local_dict["T_ITLC_XP"]          = "XP";

// iTLC - TLC Facilities
local_dict["T_TLCFA_TLC"] = "TLC Facilities";
local_dict["T_ITLC_TLC_ID"] = "ID";
local_dict["T_ITLC_TLC_COMPANY"] = "Company";
local_dict["T_ITLC_TLC_VERSION"] = "TLCFA Version";

// iTLC - Applicaties
local_dict["T_ITS_APP"]        = "ITS App";
local_dict["T_TLCFA_APP"]      = "ITS Applications";
local_dict["T_USERNAME"]       = "Username";
local_dict["T_SESSION_STATE"]  = "Session state";
local_dict["T_CONTROL_STATE"]  = "Control state";
local_dict["T_PROGRAM_NUMBER"] = "Program number";
local_dict["T_USER_VALID"]     = "User valid";
local_dict["T_TLCFA_APP_DIAG"] = "Application diagnostics";
local_dict["T_CONNECT_TICK"]   = "Last valid login";
local_dict["T_ALIVE_TICK"]     = "Last Alive()";
local_dict["T_JSON_COUNT"]     = "JSON error count";
local_dict["T_TLCFA_APP_CP"]   = "Select Manual ITS-A";

// iTLC - Intersections (XP)
local_dict["T_TLCFA_XP"]       = "Intersections";
local_dict["T_ITLC_XP_SOURCE"] = "Source";

// iTLC - Signalgroups
local_dict["T_TLCFA_SG"] = "Signal groups";
local_dict["T_TLCFA_SG_PREDICTIONS"] = "Signal group predictions";
local_dict["T_TLCFA_SG_TIMES"] = "Signal group times";
local_dict["T_TLCFA_RAG_TEST"] = "Embedded RAG Test";
local_dict["T_TLCFA_SG_CONFLICT"] = "Clearance times";

// iTLC - Detectors
local_dict["T_TLCFA_DET"] = "Detectors";
local_dict["T_ITLC_DET_EVENTS"] = "Generates Events";

// iTLC - Inputs
local_dict["T_TLCFA_IN"] = "Inputs";

// iTLC - Outputs
local_dict["T_TLCFA_OUT"] = "Outputs";

// iTLC - Variabelen
local_dict["T_TLCFA_VAR"] = "Variables";
local_dict["T_LIFETIME"] = "Lifetime";
local_dict["T_DEFAULT_VALUE"] = "Default value";

// iTLC - Backup
local_dict["T_ITLC_BACKUP_OVERVIEW"] = "Overview backup applications";
local_dict["T_ITLC_BACKUP_ACTIVE"] = "Current selected application";

// iTLC - Logbook
local_dict["ITLC_LEVEL"] = "Level";
local_dict["ITLC_SECTION"] = "Section";
local_dict["ITLC_MESSAGE"] = "Message";

// Safenet FWUPDATE
local_dict["CELL_SAFENET_FWUPDATE"] = "Firmware update";
local_dict["CELL_SAFENET_FWUPDATE_UCB_CFG"] = "Supervisor configuration";
local_dict["SAFENET_FWUPDATE"] = "Firmware update";
local_dict["T_FWU_DEPLOY"] = "Deploy";
local_dict["T_FWU_XLS12_UCB_FW"] = "ucB FW";
local_dict["T_FWU_XLS12_UCA_FW"] = "ucA FW";
local_dict["T_FWU_XLS12_UCB_CFG"] = "ucB CFG";

// PeriNet FWUPDATE 
local_dict["CELL_PERINET_FWUPDATE"] = "Firmware update";
local_dict["PERINET_FWUPDATE"] = "Firmware update";

local_dict["T_FWU_XIO16_FW"] = "XIO16 FW";
local_dict["T_FWU_XD16_FW"] = "XD16 FW";
local_dict["T_FWU_XSER6_FW"] = "XSER6 FW";

// FWUPDATE 
local_dict["T_FWU_TRIGGERS"] = "Triggers";
local_dict["T_FWU_VERSION"] = "Version";
local_dict["T_FWU_LOCK_STATE"] = "Lock state";
local_dict["T_FWU_MODULE_STATE"] = "Module state";
local_dict["T_FWU_FW_STATE"] = "FW state";
local_dict["T_FWU_CFG_STATE"] = "CFG state";
local_dict["T_FWU_SRV_OPTIONS"] = "Service options";

local_dict["T_FWU_UNITS"] = "Units";
local_dict["T_FWU_MAC_ADDRESS"] = "MAC";
local_dict["T_FWU_UNIT_TYPE"] = "Type";
local_dict["T_FWU_UNIT_DEPL_STATE"] = "Deploy state";
local_dict["T_FWU_ACTIVE_IMAGE"] = "Active image";
local_dict["T_FWU_APP_VERSION"] = "FW ver.";
local_dict["T_FWU_CFG_VERSION"] = "CFG ver.";
local_dict["T_FWU_BL_VERSION"] = "Boot ver.";
local_dict["T_FWU_SLOT"] = "Slot";
local_dict["T_FWU_STATE"] = "status";
local_dict["T_FWU_REFRESH"] = "Refresh unit versions";
local_dict["T_FWU_ACTIVATE_SLOT"] = "Activate slot";
local_dict["T_FWU_UNLOCK_SLOT"] = "Unlock slot";
local_dict["T_FWU_ACTIVE_SLOT"] = "Active slot";

local_dict["T_FWU_FW_REPOSITORY"] = "Firmware repository";
local_dict["T_FWU_CFG_REPOSITORY"] = "Configuration repository";
local_dict["T_FWU_UNIT_PROCESS"] = "Unit identification";
local_dict["T_FWU_REPO_STATE"] = "Repository state";
local_dict["T_FWU_REPO_ID_STATE"] = "Identification";
local_dict["T_FWU_BUILD"] = "Build";
local_dict["T_FWU_ACTIVE_BUILD"] = "Active image build";
local_dict["T_FWU_REPO_CFG_STATE"] = "Repository state";

local_dict["T_FWU_DEPLOY_TIMEOUT"] = "Deploy timeout";
local_dict["T_FWU_DEPLOY_BACKOFF"] = "Deploy backoff";
local_dict["T_FWU_LAST_SEEN"] = "Last seen";

// Certifications
local_dict["T_CERT_TYPE"]      = "Type";
local_dict["T_CERT_NAME"]      = "Name";
local_dict["T_CERT_VERSION"]   = "Version";
local_dict["T_CERT_EXPDATE"]   = "Exp. Date";
local_dict["T_CERT_COMPANY"]   = "Company Name";

// Certificates
local_dict["T_CERT_CERTIFICATE"]    = "Certificate";
local_dict["T_CERT_DATE_CREATED"]   = "Date created";
local_dict["T_CERT_DATE_EXPIRED"]   = "Date expired";
local_dict["T_CERT_NAME_AUTHORITY"] = "Authority";

// Timer monitoring
local_dict["T_TIMMON_100DELTA"] = "Delta 100ms";
local_dict["T_TIMMON_100EXE"] = "100ms execution";
local_dict["T_TIMMON_AVG"] = "Average (ms)";
local_dict["T_TIMMON_MAX"] = "Maximum (ms)";
local_dict["T_TIMMON_MIN"] = "Minimum (ms)";
local_dict["T_TIMMON_OFFSET"] = "Offset (ms)";
local_dict["T_TIMMON_RESET_TIMERS"] = " Reset timers";


// CLOG
local_dict["CLOG_LEVEL"] = "Level";
local_dict["CLOG_SECTION"] = "Section";
local_dict["CLOG_MESSAGE"] = "Message";

// FBI 
local_dict["CELL_ITC_FBI_LOGBOOK"]    = "FBI";
