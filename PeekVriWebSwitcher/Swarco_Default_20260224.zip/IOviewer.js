﻿// global canvas and context
var fillCanvas, fillContext,  siteCanvas, siteContext, labelCanvas, labelContext;
var outlineImage = new Image();
var colorTable;
var mimicViewIni = new Array();
var isRunning=false;
var IO_INNameTable;
var IO_INStatusTable;
var IO_INRefresh=true;
var IO_OUTNameTable;
var IO_OUTStatusTable;
var IO_OUTRefresh=true;
var MTSNameTable;
var MTSStatusTable;
var MTSRefresh=true;
var waitTimer;
var SHORT_TIMEOUT=200;
var LONG_TIMEOUT=200;

var toBinary = function(decNum){
    var x = parseInt(decNum,10).toString(2);
    while(x.length < 8) {
        x = "0" + x;
    }
    return x.split("").reverse().join("");
}

function getIOnum(val) { 
    
    var status = val.split('\n');
    var i;
    var result="";
    for (i = 0; i < status.length; i++) {
    result += toBinary(status[i]);
    }
    var endResult = result.split("");
    return(endResult);
}

function getIO_INnames(val) { 
    
    var numIP = val.split('\n').length * 8;
    var i;
    var result="";
    for (i = 0; i < (numIP -1); i++) {
    result += "IP" + (i+1) + ",";
    }
    result = result + "IP" + numIP;
    var endResult = result.split(",");
    return(endResult);
}

function getIO_OUTnames(val) { 
    
    var numOP = val.split('\n').length * 8;
    var i;
    var result="";
    for (i = 0; i < (numOP -1); i++) {
    result += "OP" + (i+1) + ",";
    }
    result = result + "OP" + numOP;
    var endResult = result.split(",");
    return(endResult);
}

function getMTSnames(val) { 
    
    var numLP = val.split('\n').length * 8;
    var i;
    var result="";
    for (i = 0; i < (numLP -1); i++) {
    result += "LP" + (i+1) + ",";
    }
    result = result + "LP" + numLP;
    var endResult = result.split(",");
    return(endResult);
}



function checkIfInsideButtonCoordinates(buttonObj, mouseX, mouseY) 
{                
	if (((mouseX > buttonObj.x)
			&& (mouseX < (buttonObj.x + buttonObj.w)))
		&& ((mouseY > buttonObj.y)
			&& (mouseY < (buttonObj.y + buttonObj.h))))   
		return true;              
	else              
		return false;        
}


window.onload = ( function() 
{
	loadMimicViewerIni();
});

function drawMimicview()
{
	fillCanvas = document.getElementById('fillCanvas');
	fillContext = fillCanvas.getContext('2d');
	labelCanvas = document.getElementById('labelCanvas');
	labelContext = labelCanvas.getContext('2d');
	siteCanvas = document.getElementById('mimicviewer'); 
	siteContext = siteCanvas.getContext('2d');
    
	fillContext.clearRect(0,0,650, 550);
	siteContext.clearRect(0,0,650, 550);
	labelContext.clearRect(0,0,650, 550);
	
	outlineImage = new Image();
	
	// Register to the image on-load event. Using JQuery to avoid browser incompatibility issues.
	$(outlineImage).load( function() {
		// draw the loaded image on the source canvas
		siteContext.drawImage(outlineImage, 0, 0);
		//fillContext.drawImage(outlineImage, 0, 0);
		startMonitoring();
	});
	outlineImage.src = 'IO.png';
}


function loadMimicViewerIni()
{
	$.get("./IO.ini", function(data)
	{
		mimicViewIni=parseINIString(data);
	}).fail(function() { 
	});
	IO_INRefresh=true;
   IO_OUTRefresh=true;
   MTSRefresh=true;
	loadColorTable();
}
function loadColorTable()
{
	$.get("./IOcolors.ini", function(data)
	{
		colorTable=parseINIString(data);

		// convert it into right format
		for (var section in colorTable)
		{
			for (var status in colorTable[section])
			{
				// Fill Colour: Convert the one hex colour to three separate RGB colours
				var StateInfo = colorTable[section][status].split(",");
				var bigintFill = parseInt(StateInfo[0].replace("#",""), 16);
				var fillColorR = (bigintFill >> 16) & 255;
				var fillColorG = (bigintFill >> 8) & 255;
				var fillColorB = bigintFill & 255;
				var fillColor = fillColorR + "," + fillColorG +","+ fillColorB;

				// Hatch Colour: Convert the one hex colour to three separate RGB colours
				// For backwards compatibility check if the new parameter is present
				var hatchColor = undefined
				if (StateInfo[3] != undefined)
				{
					var bigintHatch = parseInt(StateInfo[3].replace("#",""), 16);
					var hatchColorR = (bigintHatch >> 16) & 255;
					var hatchColorG = (bigintHatch >> 8) & 255;
					var hatchColorB = bigintHatch & 255;
					hatchColor = hatchColorR + "," + hatchColorG +","+ hatchColorB;
				}

				var StateInfoArray = new Array();
				StateInfoArray["fillColor"] = fillColor;
				StateInfoArray["hatchMode"] = StateInfo[1];
				StateInfoArray["hatchDensity"] = StateInfo[2];
				StateInfoArray["hatchColor"] = hatchColor;
				colorTable[section][status] = StateInfoArray;			
			}
		}

		loadIONames();
	});
}

function loadIONames()
{
   
$.get("./parv/XIO3.BOR/").done(function() {

    $.get("./parv/XIO3.BOR/", function(data)
    {
        IO_INNameTable = getIO_INnames(data);
        IO_OUTNameTable = getIO_OUTnames(data);
        loadMTSNames();      
    }
    )}).fail(function() {
       loadMTSNames();
    })
}

function loadMTSNames()
{
    $.get("./part/XDET.CNF/", function(data)
    {
       if (data.includes("XLD")) 
       { 
       $.get("./parv/XLD.BRT/", function(data)
       {
       MTSNameTable = getMTSnames(data);
		 drawMimicview();       
       });
       }
       else
       {
		 drawMimicview();
       }
    })
}

function startMonitoring()
{
	// First time we get here?
	if ( !isRunning)
	{
		getIO_INData();	// Starts a background timer-based continuous update of the Detectors, Lamps, Outputs and Inputs.
		isRunning = true;	
	}
	else  // We were already running and the user selected another SiteView (or whatever)
	{
		try
		{
			clearTimeout(waitTimer);	// Stop the background I/O update task.
			drawStatus(IO_INStatusTable, "IO_IN", "IO_IN", IO_INStatusTable, IO_INNameTable, IO_INRefresh);
         drawStatus(IO_OUTStatusTable, "IO_OUT", "IO_OUT", IO_OUTStatusTable, IO_OUTNameTable, IO_OUTRefresh);
         drawStatus(MTSStatusTable, "MTS", "MTS", MTSStatusTable, MTSNameTable, MTSRefresh);
		}
		catch(err)
		{
	   //Handle errors here
      IO_INRefresh=true;
      IO_OUTRefresh=true;
      MTSRefresh=true;
		}
		getIO_INData();		// Restart the background I/O update task
	}
}

// create  objects from ini file
function parseINIString(data)
{
	var regex = {
	    section: /^\s*\[\s*([^\]]*)\s*\]\s*$/,
	    param: /^\s*([\w\.\-\_]+)\s*=\s*(.*?)\s*$/,
	    comment: /^\s*;.*$/
	};
	var value = {};
	var lines = data.split(/\r\n|\r|\n/);
	var section = null;

	for(var x=0;x<lines.length;x++)
	{
	    if(regex.comment.test(lines[x])){
	        return;
	    }else if(regex.param.test(lines[x])){
	        var match = lines[x].match(regex.param);
	        if(section){
	            value[section][match[1]] = match[2];
	        }else{
	            value[match[1]] = match[2];
	        }
	    }else if(regex.section.test(lines[x])){
	        var match = lines[x].match(regex.section);
	        value[match[1]] = {};
	        section = match[1];
	    }else if(lines[x].length == 0 && section){
	        section = null;
	    };
	}

	return value;
}


function getIO_INData ( )
{ 
	if (mimicViewIni["IO_IN"] == undefined)
	{
		// nothing todo go to next get data function
		setTimeout("getIO_OUTData()",SHORT_TIMEOUT);
		return;
	}
	$.get("./parv/XIO3.BOR/", function(data)
	{
		var status = getIOnum(data);
		drawStatus(status,"IO_IN","IO_IN",IO_INStatusTable,IO_INNameTable,IO_INRefresh);
		IO_INStatusTable=status;
		IO_INRefresh=false;
      
	}).fail(function() {IO_INRefresh=true; })
	.always(function() {waitTimer=setTimeout("getIO_OUTData()",LONG_TIMEOUT); });
}

function getIO_OUTData ( )
{ 
	if (mimicViewIni["IO_OUT"] == undefined)
	{
		// nothing todo go to next get data function
		setTimeout("getMTSData()",SHORT_TIMEOUT);
		return;
	}
	$.get("./parv/XIO3.BMO/", function(data)
	{
		var status = getIOnum(data);
		drawStatus(status,"IO_OUT","IO_OUT",IO_OUTStatusTable,IO_OUTNameTable,IO_OUTRefresh);
		IO_OUTStatusTable=status;
		IO_OUTRefresh=false;
      
	}).fail(function() {IO_OUTRefresh=true; })
	.always(function() {waitTimer=setTimeout("getMTSData()",LONG_TIMEOUT); });
}

function getMTSData ( )
{
    $.get("./part/XDET.CNF/", function(data)
    {
       if (data.includes("XLD")) 
       { 
       $.get("./parv/XLD.BRT/", function(data)
	{
		var status = getIOnum(data);
		drawStatus(status,"MTS","MTS",MTSStatusTable,MTSNameTable,MTSRefresh);
		MTSStatusTable=status;
		MTSRefresh=false;
	}).fail(function() {MTSRefresh=true;})
	.always(function() {waitTimer=setTimeout("getIO_INData()",LONG_TIMEOUT); });  
       }
       else
       {
       setTimeout("getIO_INData()",SHORT_TIMEOUT);
		 return;
       }
    })
}


function drawStatus(newStatusTable, tag, colorTag, lastStatusTable, nameTable,refreshToggle)
{
	var width = fillContext.canvas.width;
	var height = fillContext.canvas.height;
	var fillImageData = fillContext.getImageData(0, 0, width, height);
	var outlineData = siteContext.getImageData(0, 0, width, height);
	
	/* In IE11 a problem occurred that the detector status in the siteviewer is not shown correctly */
	/* Problem is that for some reason, in IE11, the getImageData/putImageData functions don't work the first time they are called */
	/* To fix this problem, always refresh the siteviewer while using IE */
	if ((navigator.userAgent.indexOf('MSIE') !== -1) || (navigator.appVersion.indexOf('Trident/') > 0))
	{
		refreshToggle = true;
	}
	
	if (mimicViewIni[tag] == undefined )
	{
		return;
	}
	if (newStatusTable == undefined)
	{
		// can sometimes happen during switching between SiteViewer, is automatically solved the next time 
		return;
	}
	if (lastStatusTable == undefined)
	{ 
		// for the first time no 
		lastStatusTable = newStatusTable;
	}
	
	for (var i=0;i<newStatusTable.length;i++)
	{
		// Figure out if name is in lower or upper case
		var Name = nameTable[i].toLowerCase();
		var exists = false;
		if(mimicViewIni[tag][Name]!=undefined) {
			exists = true;
		}
		else if(mimicViewIni[tag][Name.toUpperCase()]!=undefined) {
			Name = Name.toUpperCase();
			exists = true;
		}

		if(exists) {
			if (Name in colorTable) {
				colorTag = Name;
			}
			if ((refreshToggle || lastStatusTable[i] != newStatusTable[i])
				&& colorTable[colorTag] != undefined
				&& newStatusTable[i] != undefined
				&& colorTable[colorTag][newStatusTable[i]]["fillColor"] != undefined
				)
			{
				var xy = mimicViewIni[tag][Name].split(',');
				for (var idx=0;idx<xy.length;idx+=2)
				{
					myFloodFill(parseInt(xy[idx]), parseInt(xy[idx+1]),
						colorTable[colorTag][newStatusTable[i]]["fillColor"],
						colorTable[colorTag][newStatusTable[i]]["hatchMode"],
						colorTable[colorTag][newStatusTable[i]]["hatchColor"],
						colorTable[colorTag][newStatusTable[i]]["hatchDensity"],
						fillImageData, outlineData, width, height);
				}
			}
		}
	}

	// redraw the overlay
	fillContext.putImageData(fillImageData, 0, 0);

	return;	
}

// Note: for backwards compatibility the new parameters hatchMode, hatchColor, hatchDensity are allowed to be 'undefined'.
function myFloodFill(x, y, curColor, hatchMode, hatchColor, hatchDensity, fillImageData, outlineData, width, height) {
    var stack = [];
    var oPixels = outlineData.data;
    var hatchPixels = new Array();
    
    var rgb = curColor.split(',');
    var curColorR = parseInt(rgb[0]);
    var curColorG = parseInt(rgb[1]);  
    var curColorB = parseInt(rgb[2]);
    
    // do the first pixel
    pixelAddress = (y * width + x) * 4;
    // take original pixel colour to fill
    var targetColour = new Array();
	targetColour[0] = oPixels[pixelAddress];
	targetColour[1] = oPixels[pixelAddress+1];
	targetColour[2] = oPixels[pixelAddress+2];
	
    if ( compareAndDraw(pixelAddress, oPixels, hatchPixels,fillImageData,curColorR,curColorG,curColorB, targetColour, hatchMode, hatchDensity, x, y) )
    {
        if (!stack.push(x, y)) {
            return;
        }
    }
    
    while (stack.length > 0) {
        y = stack.pop();
        x = stack.pop();
        pixelAddress = (y * width + x) * 4;

        // check the neighbours
        // left
        if ( x >= 0 &&compareAndDraw(pixelAddress-4, oPixels, hatchPixels,fillImageData,curColorR,curColorG,curColorB, targetColour, hatchMode, hatchDensity, x -1, y) )
        {
            if (!stack.push(x-1, y)) {
                return;
            }
        }
                
        // right
        if ( x < width &&compareAndDraw(pixelAddress+4, oPixels, hatchPixels,fillImageData,curColorR,curColorG,curColorB, targetColour, hatchMode, hatchDensity, x +1, y) )
        {
            if (!stack.push(x+1, y)) {
                return;
            }
        }
        
        // below
        if ( y <= height &&compareAndDraw(pixelAddress+ (width*4), oPixels, hatchPixels,fillImageData,curColorR,curColorG,curColorB, targetColour, hatchMode, hatchDensity, x, y +1) )
        {
            if (!stack.push(x, y+1)) {
                return;
            }
        }
        
        // above
        if ( y > 0 &&compareAndDraw(pixelAddress-(width*4), oPixels, hatchPixels,fillImageData,curColorR,curColorG,curColorB, targetColour, hatchMode, hatchDensity, x, y -1) )
        {
            if (!stack.push(x, y-1)) {
                return;
            }
        }
  
        // for debugging...
        //fillCtx.putImageData(fillImageData, 0, 0);
    }

	// Draw the hatch pixels
	if (hatchMode != undefined)		// for backwards compatibility.
	{
		var rgbHatch = hatchColor.split(',');
		var rgbHatchR = parseInt(rgbHatch[0]);
		var rgbHatchG = parseInt(rgbHatch[1]);  
		var rgbHatchB = parseInt(rgbHatch[2]);

		for (var i=0; i<hatchPixels.length; i++) {
			fillImageData.data[hatchPixels[i]] = rgbHatchR;
			fillImageData.data[hatchPixels[i] + 1] = rgbHatchG;
			fillImageData.data[hatchPixels[i] + 2] = rgbHatchB;
			fillImageData.data[hatchPixels[i] + 3] = 255;
		}
	}
}

compareAndDraw = function(pixelAddress, oPixelData, hatchPixels, fillImageData, fillR, fillG, fillB, targetColour, hatchMode, hatchDensity, x, y) {
	// if same as targetColour then it is not a border
	if (oPixelData[pixelAddress] == targetColour[0] &&
		oPixelData[pixelAddress+1] == targetColour[1] &&
		oPixelData[pixelAddress+2] == targetColour[2])
	{
		// If the current pixel matches the fill colour or the hatchcolour
		if (fillImageData.data[pixelAddress] === fillR &&
			fillImageData.data[pixelAddress + 1] === fillG &&
			fillImageData.data[pixelAddress + 2] === fillB)
		{
			// already filled
			return false;
		} else {
			if (isHatchPixel(x, -y, hatchMode, hatchDensity)) {
				// draw the hatch pixel 
				hatchPixels.push(pixelAddress);
			} 
			// draw the fill pixel 
			fillImageData.data[pixelAddress] = fillR;
			fillImageData.data[pixelAddress + 1] = fillG;
			fillImageData.data[pixelAddress + 2] = fillB;
			fillImageData.data[pixelAddress + 3] = 255;

			return true;
		}
	}

	// it is a border
	return false;
};

 
isHatchPixel = function(pixelX, pixelY, hatchMode, hatchDensity) {
	//hatchmode 0 = nohatch
	//hatchmode 1 = lefthatch
	//hatchmode 2 = righthatch
	//hatchmode 3 = bothhatch
	if ( (hatchMode == undefined)
		|| (hatchDensity == undefined)
		|| (hatchMode == 0)
		) {
		return false;
	}
	if (hatchMode == 1 || hatchMode == 3) {
		var pixelTmpA = Math.abs(pixelY) - pixelX;
		if ((pixelTmpA % hatchDensity) === 0) {
			var hatchLeft = true;
		} else {
			var hatchLeft = false;
		}
	}
	if (hatchMode == 2 || hatchMode == 3) {
		var pixelTmpB = pixelY - pixelX;
		if ((pixelTmpB % hatchDensity) === 0) {
			var hatchRight = true;
		} else {
			var hatchRight = false;
		}
	}
	if ( hatchLeft || hatchRight ) {
		return true;  
	} else {
		return false;  
	}
}

